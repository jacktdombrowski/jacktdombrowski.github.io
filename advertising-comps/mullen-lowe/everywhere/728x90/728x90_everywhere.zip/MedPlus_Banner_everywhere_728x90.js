(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"MedPlus_Banner_everywhere_728x90_atlas_", frames: [[0,0,600,400],[0,402,600,400]]}
];


// symbols:



(lib.Humanitarian1 = function() {
	this.spriteSheet = ss["MedPlus_Banner_everywhere_728x90_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Humanitarian2 = function() {
	this.spriteSheet = ss["MedPlus_Banner_everywhere_728x90_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtline2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAPIAAgdIAdAAIAAAdg");
	this.shape.setTransform(167.6,10.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBDIAAg1IgzhPIAiAAIAfA1IAgg1IAiAAIg0BPIAAA1g");
	this.shape_1.setTransform(160.1,5.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXBDIgbgrIgYAAIAAArIgcAAIAAiEIA7AAQAJgBANAEQALADAGAHQAGAFADAJQACAHAAAKIAAAAQAAAIgCAGQgBAHgFAEQgDAFgGAEQgFADgGADIAhAwgAgcgBIAdAAQAGAAAEgBQAEgBADgDQADgDABgDQACgEAAgDIAAgBQAAgFgCgDQgCgEgDgDIgHgDIgJgBIgdAAg");
	this.shape_2.setTransform(147,5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAoBDIgMgeIg4AAIgLAeIgfAAIA6iFIAaAAIA4CFgAARAMIgRgrIgRArIAiAAg");
	this.shape_3.setTransform(132.1,5.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOBDIAAhpIgoAAIAAgbIBtAAIAAAbIgpAAIAABpg");
	this.shape_4.setTransform(120.5,5.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNBDIAAiEIAbAAIAACEg");
	this.shape_5.setTransform(111.2,5.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgvBDIAAiEIAdAAIAABpIBCAAIAAAbg");
	this.shape_6.setTransform(102.6,5.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNBDIAAiEIAcAAIAACEg");
	this.shape_7.setTransform(93.1,5.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAmBDIAAhWIgmA3IAAAAIglg3IAABWIgdAAIAAiEIAgAAIAiA4IAjg4IAfAAIAACEg");
	this.shape_8.setTransform(81.7,5.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgyBDIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_9.setTransform(61.7,5.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAbBDIAAg2Ig1AAIAAA2IgdAAIAAiEIAdAAIAAA0IA1AAIAAg0IAdAAIAACEg");
	this.shape_10.setTransform(47.8,5.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNBDIAAhpIgpAAIAAgbIBtAAIAAAbIgoAAIAABpg");
	this.shape_11.setTransform(34.5,5.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAiBDIg/hUIAABUIgdAAIAAiEIAbAAIA+BRIAAhRIAcAAIAACEg");
	this.shape_12.setTransform(15.1,5.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgOBDIAAiEIAdAAIAACEg");
	this.shape_13.setTransform(4.5,5.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2b, new cjs.Rectangle(-0.7,-5,173.3,23), null);


(lib.txtline2a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBDQgHgBgHgDQgIgDgGgEQgHgDgFgGIARgUQAJAHAKAEIAJADIAKABQAJAAAGgDQAEgDAAgGIAAAAQAAgGgEgEQgGgDgQgFQgKgCgIgDQgIgDgFgEQgHgEgCgHQgEgGAAgKIAAAAQAAgJAEgHQAEgIAGgGQAGgEAJgEQAIgDAKAAIANABIANAEQAHACAFADIAKAIIgPAVQgIgGgJgDQgJgDgHgBQgJABgEADQgFADABAFIAAAAQAAAHAFADQAGADARAFQAKACAIAEQAHAEAFADQAGAFADAGQADAHAAAIQAAAKgEAIQgEAIgGAEQgHAGgJADQgJACgKAAQgHAAgIgBg");
	this.shape.setTransform(397.6,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAXBCIgcgqIgWAAIAAAqIgdAAIAAiEIA7AAQAJAAAOAEQAKADAGAHQAFAGAEAHQACAIABAJIAAABQgBAHgBAIQgDAGgEAEQgDAFgGAEQgEADgHADIAgAvgAgbgBIAcAAQAFAAAFgCQAEAAADgDQADgDABgDQACgDAAgFIAAAAQAAgEgCgFQgCgDgCgCIgIgEIgJgBIgcAAg");
	this.shape_1.setTransform(385.3,10.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyBCIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_2.setTransform(371.9,10.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgyBCIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_3.setTransform(359.2,10.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAXBCIgbgqIgYAAIAAAqIgdAAIAAiEIA8AAQAJAAANAEQAKADAHAHQAFAGADAHQADAIABAJIAAABQgBAHgCAIQgCAGgDAEQgEAFgFAEQgGADgGADIAgAvgAgcgBIAeAAQAEAAAFgCQAEAAADgDQADgDABgDQACgDAAgFIAAAAQAAgEgCgFQgCgDgCgCIgHgEIgKgBIgdAAg");
	this.shape_4.setTransform(346.2,10.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAoBDIgMgeIg4AAIgMAeIgdAAIA4iFIAaAAIA5CFgAASALIgSgqIgRAqIAjAAg");
	this.shape_5.setTransform(331.3,10.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHBDIgMgDQgGgDgGgEIgKgIIgIgKQgEgFgCgHQgDgGgBgHIgCgNIAAgBIACgNQABgHADgFIAGgNIAIgKQAEgFAGgDQAGgEAGgCIANgFQAHgBAHAAQAJAAAIABQAHACAHADQAJAEANAKIgTAWQgIgHgIgEQgIgEgLAAQgHAAgHADQgHAEgFAFQgFAGgDAIQgDAHAAAIIAAAAQAAAIADAIQADAIAFAGQAFAFAHADQAHAEAHAAQAJAAALgEQAHgEAJgIIATATIgLAKQgGAEgHAEQgGADgIABQgIACgJAAQgHAAgHgCg");
	this.shape_6.setTransform(317,10.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgvBCIAAiEIAdAAIAABqIBCAAIAAAag");
	this.shape_7.setTransform(298.7,10.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAoBDIgMgeIg4AAIgMAeIgdAAIA4iFIAaAAIA5CFgAARALIgRgqIgRAqIAiAAg");
	this.shape_8.setTransform(284.9,10.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgHBDIgMgDQgHgDgFgEIgKgIIgIgKQgEgFgCgHQgDgGgBgHIgCgNIAAgBIACgNQABgHADgFIAFgNIAJgKQAFgFAFgDQAFgEAHgCIANgFQAHgBAHAAQAJAAAIABQAHACAHADQAJAEANAKIgTAWQgIgHgIgEQgIgEgKAAQgIAAgHADQgGAEgGAFQgFAGgDAIQgDAHAAAIIAAAAQAAAIADAIQADAIAFAGQAFAFAHADQAHAEAIAAQAHAAAMgEQAHgEAJgIIATATIgLAKQgGAEgHAEQgGADgIABQgIACgJAAQgHAAgHgCg");
	this.shape_9.setTransform(270.5,10.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNBCIAAiEIAbAAIAACEg");
	this.shape_10.setTransform(260.2,10.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag8BCIAAiEIA0AAIAOACQAHABAGADIAMAGIALAHIAIAKQAEAFACAHQADAFABAHQABAGAAAHIAAAAQAAAHgBAGQgBAHgDAGQgCAGgEAGIgIAKIgLAIIgMAGQgGACgHABQgHACgHgBgAgfAoIAXAAQAIAAAHgDQAHgCAGgGQAFgGADgGQADgIAAgIIAAgBQAAgHgDgIQgDgIgFgFQgGgFgHgDQgHgDgIAAIgXAAg");
	this.shape_11.setTransform(249.9,10.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyBCIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_12.setTransform(236.1,10.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAmBCIAAhWIgmA5IAAAAIglg4IAABVIgdAAIAAiEIAgAAIAiA5IAjg5IAfAAIAACEg");
	this.shape_13.setTransform(221.3,10.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHBDIgOgDIgMgHIgKgIIgIgKIgHgLQgCgHgBgHIgCgNIAAgBIACgNQABgHADgFIAGgNQADgFAGgFQAEgFAGgDQAFgEAGgCIAOgFIANgBQAJAAAIABQAHABAGADQAJADANAKIgSAXQgIgIgIgCQgIgEgLAAQgGAAgIADQgHAEgFAFQgFAGgDAIQgDAHAAAIIAAAAQAAAJADAIQADAIAFAFQAGAGAHADQAIADAHAAQAIAAAIgCQAGgCAGgEIAAgTIgeAAIAAgYIA7AAIAAA5QgQALgJAEQgHADgJABQgHACgKAAIgNgCg");
	this.shape_14.setTransform(199.8,10.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAiBCIg/hTIAABTIgdAAIAAiEIAbAAIA+BRIAAhRIAcAAIAACEg");
	this.shape_15.setTransform(185,10.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNBCIAAiEIAcAAIAACEg");
	this.shape_16.setTransform(174.3,10.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgNBCIAAhpIgpAAIAAgbIBtAAIAAAbIgoAAIAABpg");
	this.shape_17.setTransform(165,10.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgOBCIAAiEIAdAAIAACEg");
	this.shape_18.setTransform(155.7,10.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHBDIgMgDQgGgDgGgEIgKgIIgIgKQgEgFgDgHQgCgGgBgHIgCgNIAAgBIACgNQABgHACgFIAHgNIAIgKQAEgFAGgDQAGgEAGgCIAOgFQAFgBAIAAQAJAAAIABQAIACAGADQAJAEAMAKIgSAWQgJgHgHgEQgIgEgLAAQgHAAgHADQgHAEgFAFQgFAGgDAIQgDAHAAAIIAAAAQAAAIADAIQADAIAFAGQAFAFAHADQAHAEAHAAQAJAAALgEQAHgEAIgIIATATIgKAKQgGAEgGAEQgHADgIABQgIACgJAAQgHAAgHgCg");
	this.shape_19.setTransform(145.6,10.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAeBCIgegtIgeAtIggAAIAuhCIgshCIAiAAIAbArIAcgrIAhAAIgsBCIAuBCg");
	this.shape_20.setTransform(131.5,10.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgyBCIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_21.setTransform(118.5,10.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAXBCIgbgqIgYAAIAAAqIgdAAIAAiEIA8AAQAJAAANAEQAKADAHAHQAGAGACAHQADAIAAAJIAAABQAAAHgCAIQgBAGgFAEQgDAFgGAEQgFADgGADIAhAvgAgcgBIAeAAQAFAAAEgCQAEAAADgDQADgDABgDQACgDAAgFIAAAAQAAgEgCgFQgBgDgEgCIgGgEIgKgBIgdAAg");
	this.shape_22.setTransform(99.8,10.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgyBCIAAiEIBjAAIAAAaIhGAAIAAAbIA+AAIAAAZIg+AAIAAAcIBIAAIAAAag");
	this.shape_23.setTransform(86.4,10.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgMBDIg2iFIAhAAIAhBcIAjhcIAgAAIg2CFg");
	this.shape_24.setTransform(72.6,10.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgOBDIgOgDQgGgDgFgEQgGgEgFgEIgIgLIgGgLQgDgGgBgHQgCgHAAgGIAAgBIACgNIAEgMIAGgNIAIgKIALgIQAFgEAHgCIANgFIAOgBQAIAAAHABIAOAFIAMAGQAFADAFAFQAFAFADAFIAGAMIAEANQACAGAAAHIAAAAIgCAOIgEANIgGALIgIAKIgLAJIgMAHIgNADIgPACQgHAAgHgCgAgPgmQgIAEgFAFQgFAGgDAIQgDAHAAAIIAAAAQAAAIADAIQADAIAFAGQAGAFAHADQAIAEAHAAQAJAAAHgEQAIgDAFgFQAFgGADgHQADgIAAgIIAAgBQAAgHgDgIQgDgHgFgHQgGgFgHgEQgIgDgIAAQgIAAgHADg");
	this.shape_25.setTransform(57.4,10.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgGBDIgOgDQgGgDgFgEIgKgIIgIgKQgEgFgDgHQgCgGgBgHQgCgHABgGIAAgBQgBgGACgHQABgHACgFIAGgNIAJgKQAEgFAGgDQAGgEAGgCIANgFQAHgBAHAAQAJAAAIABQAIACAGADQAIAEANAKIgSAWQgIgHgIgEQgJgEgJAAQgIAAgHADQgHAEgFAFQgFAGgDAIQgDAHAAAIIAAAAQAAAIADAIQADAIAFAGQAFAFAHADQAHAEAIAAQAHAAAMgEQAHgEAIgIIAUATIgMAKQgFAEgHAEQgGADgIABQgIACgJAAQgHAAgGgCg");
	this.shape_26.setTransform(42.5,10.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLBDQgHgBgHgDQgIgDgGgEQgHgDgFgGIAQgUQAKAHAKAEIAKADIAKABQAJAAAEgDQAGgDAAgGIAAAAQAAgGgGgEQgFgDgQgFQgKgCgHgDQgJgDgGgEQgGgEgCgHQgDgGgBgKIAAAAQABgJADgHQADgIAHgGQAGgEAIgEQAJgDAKAAIANABIANAEQAGACAGADIALAIIgQAVQgJgGgIgDQgJgDgHgBQgIABgFADQgFADAAAFIAAAAQABAHAFADQAGADARAFQAKACAIAEQAIAEAEADQAGAFADAGQADAHgBAIQABAKgEAIQgDAIgHAEQgGAGgJADQgKACgKAAQgHAAgIgBg");
	this.shape_27.setTransform(29.2,10.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgNBCIAAiEIAcAAIAACEg");
	this.shape_28.setTransform(20.1,10.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Ag8BCIAAiEIA0AAIAOACQAHABAGADIAMAGIALAHIAIAKQAEAFACAHQADAFABAHQABAGAAAHIAAAAQAAAHgBAGQgBAHgDAGQgCAGgEAGIgIAKIgLAIIgMAGQgGACgHABQgHACgHgBgAgfAoIAXAAQAIAAAHgDQAHgCAGgGQAFgGADgGQADgIAAgIIAAgBQAAgHgDgIQgDgIgFgFQgGgFgHgDQgHgDgIAAIgXAAg");
	this.shape_29.setTransform(9.7,10.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2a, new cjs.Rectangle(0,0,406,23), null);


(lib.txtline1c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAPIAAgcIAdAAIAAAcg");
	this.shape.setTransform(48.3,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAYIhCAAIAAAaIA6AAIAAAYIg6AAIAAAbIBDAAIAAAYg");
	this.shape_1.setTransform(39.3,-21.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWA/IgagoIgWAAIAAAoIgcAAIAAh9IA5AAQAJAAANAEQAJADAGAGQAFAFADAHQACAIABAJIAAAAQgBAIgBAGQgCAGgDAEIgKAJIgKAFIAeAtgAgagBIAbAAIAJgBIAHgDQADgDABgDQACgEAAgEIAAAAQAAgFgCgDIgEgFIgHgEIgJgBIgbAAg");
	this.shape_2.setTransform(26.3,-21.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAYIhCAAIAAAaIA6AAIAAAYIg6AAIAAAbIBDAAIAAAYg");
	this.shape_3.setTransform(12.9,-21.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAaA/IAAgyIgyAAIAAAyIgcAAIAAh9IAcAAIAAAyIAyAAIAAgyIAbAAIAAB9g");
	this.shape_4.setTransform(-1,-21.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAdBAIgdhSIgcBSIgXAAIgrh+IAdAAIAaBUIAchVIAXAAIAdBVIAahUIAcAAIgrB+g");
	this.shape_5.setTransform(-18.5,-21.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgNA/IAAgxIgwhMIAgAAIAdAzIAfgzIAfAAIgwBLIAAAyg");
	this.shape_6.setTransform(-35.8,-21.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAWA/IgagoIgVAAIAAAoIgcAAIAAh9IA4AAQAIAAANAEQAJADAHAGQAFAFADAHQADAIgBAJIAAAAQABAIgCAGQgCAGgEAEIgJAJIgKAFIAfAtgAgZgBIAbAAIAJgBIAGgDQADgDABgDQACgEgBgEIAAAAQABgFgCgDIgEgFIgHgEIgJgBIgaAAg");
	this.shape_7.setTransform(-48.9,-21.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAYIhDAAIAAAaIA7AAIAAAYIg7AAIAAAbIBEAAIAAAYg");
	this.shape_8.setTransform(-62.3,-21.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgLBAIgzh+IAeAAIAgBXIAihXIAdAAIgzB+g");
	this.shape_9.setTransform(-76.1,-21.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAYIhDAAIAAAaIA7AAIAAAYIg7AAIAAAbIBEAAIAAAYg");
	this.shape_10.setTransform(-89.3,-21.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1c, new cjs.Rectangle(-97.6,-31.4,151.4,22), null);


(lib.txtline1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAPIAAgdIAdAAIAAAdg");
	this.shape.setTransform(106.3,16.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNA/IAAhkIgmAAIAAgZIBnAAIAAAZIgmAAIAABkg");
	this.shape_1.setTransform(97.9,11.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKA/QgHgBgHgCIgNgHIgMgJIARgTQAJAHAIAEIAKAEIAJABQAJAAAFgEQAEgDAAgGIAAAAQAAgFgEgEQgGgDgOgEIgRgFQgIgEgFgDQgGgDgDgHQgDgGAAgKIAAAAQAAgIAEgIQADgHAGgFQAGgEAIgDQAIgDAJAAQAGAAAHABIAMADIALAFIAKAHIgOAVQgJgGgIgDQgIgEgHABQgIgBgEAEQgEADAAAFIAAAAQAAAGAFADQAFADAQAFQAKACAHADQAIADAFAEQAFAEACAGQADAGAAAIQAAAKgDAIQgEAGgGAFQgGAFgJADQgIADgKAAQgHAAgHgCg");
	this.shape_2.setTransform(85.5,11.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgNBAIgNgEIgLgGIgKgIQgFgEgDgGIgGgLQgDgFAAgGIgCgOIAAAAIACgMQAAgGADgHIAGgLIAIgJIAKgIIALgGIANgEIANgBIAOABIANAEIALAGIAKAIQAEAEAEAFIAGALIADANIACAMIAAAAIgCANQAAAHgDAFIgGALIgIAKIgKAIIgLAGIgNAEIgOABIgNgBgAgPgkQgGADgFAGQgFAGgDAGQgDAIAAAHIAAAAQAAAIADAIQADAGAFAGQAFAFAHADQAHADAHABQAIgBAIgDQAHgDAFgFQAEgGADgGQADgIAAgIIAAAAQAAgHgDgIQgDgGgEgGQgGgGgHgDQgHgCgIAAQgHAAgIACg");
	this.shape_3.setTransform(71.5,11.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAjA/IAAhSIgjA2IAAAAIgig1IAABRIgcAAIAAh9IAeAAIAgA1IAhg1IAeAAIAAB9g");
	this.shape_4.setTransform(55.4,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhDAAIAAAZIA7AAIAAAYIg7AAIAAAaIBEAAIAAAZg");
	this.shape_5.setTransform(35,11.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAaA/IAAgyIgyAAIAAAyIgcAAIAAh9IAcAAIAAAyIAyAAIAAgyIAbAAIAAB9g");
	this.shape_6.setTransform(21.2,11.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNA/IAAhkIgmAAIAAgZIBnAAIAAAZIgmAAIAABkg");
	this.shape_7.setTransform(7.8,11.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1b, new cjs.Rectangle(0,1.8,111.7,22), null);


(lib.txtline1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag5A/IAAh9IAxAAIANABIAOAEQAFACAGADIAJAIIAJAJIAGALQACAFABAHIABAMIAAAAIgBANIgDAMIgGALIgJAJIgJAIQgGADgFACIgOAEIgNABgAgdAmIAVAAQAIAAAHgDQAGgDAGgEQAFgFADgHQACgIAAgHIAAgBQAAgHgCgIQgDgGgFgFQgGgFgGgDQgHgDgIAAIgVAAg");
	this.shape.setTransform(382.6,11.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhDAAIAAAZIA7AAIAAAYIg7AAIAAAaIBEAAIAAAZg");
	this.shape_1.setTransform(368.9,11.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag5A/IAAh9IAxAAIAOABIAMAEQAHACAFADIAKAIIAHAJIAGALQADAFABAHIABAMIAAAAIgBANIgEAMIgGALIgHAJIgKAIQgFADgHACIgMAEIgOABgAgdAmIAVAAQAIAAAHgDQAGgDAGgEQAFgFACgHQADgIAAgHIAAgBQAAgHgDgIQgCgGgFgFQgGgFgGgDQgHgDgIAAIgVAAg");
	this.shape_2.setTransform(355.2,11.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhCAAIAAAZIA6AAIAAAYIg6AAIAAAaIBDAAIAAAZg");
	this.shape_3.setTransform(341.5,11.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhCAAIAAAZIA6AAIAAAYIg6AAIAAAaIBDAAIAAAZg");
	this.shape_4.setTransform(328.8,11.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAgA/Ig7hPIAABPIgcAAIAAh9IAZAAIA7BMIAAhMIAbAAIAAB9g");
	this.shape_5.setTransform(314.8,11.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgKBAQgHgBgHgEIgNgFIgMgJIARgUQAJAIAIADIAKADIAJABQAJABAFgEQAEgDAAgGIAAAAQAAgGgEgCQgGgEgOgEIgRgFQgIgDgFgEQgGgEgDgGQgDgGAAgJIAAgBQAAgIAEgIQADgGAGgFQAGgFAIgDQAIgDAJAAQAGAAAHACIAMACIALAGIAKAGIgOAVQgJgGgIgDQgIgEgHAAQgIAAgEAEQgEADAAAFIAAAAQAAAGAFAEQAFACAQAEQAKADAHADQAIAEAFADQAFAFACAFQADAGAAAJQAAAJgDAIQgEAHgGAFQgGAEgJADQgIADgKAAQgHAAgHgBg");
	this.shape_6.setTransform(295.1,11.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgQAdIADg5IAeAAIAAABIgTA4g");
	this.shape_7.setTransform(286.4,7.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNA/IAAhjIgmAAIAAgaIBnAAIAAAaIgmAAIAABjg");
	this.shape_8.setTransform(277.2,11.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgNA/IAAh9IAbAAIAAB9g");
	this.shape_9.setTransform(267.8,11.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhCAAIAAAZIA6AAIAAAYIg6AAIAAAaIBDAAIAAAZg");
	this.shape_10.setTransform(252.3,11.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAWA/IgagpIgWAAIAAApIgcAAIAAh9IA5AAQAJAAAMADQAKADAGAHQAFAFADAIQACAHAAAIIAAABQAAAIgBAGQgCAGgEAEIgJAIIgKAGIAeAtgAgagBIAcAAIAJgBIAGgEQADgCABgEQABgDABgDIAAgBQgBgFgBgDIgEgGIgHgDIgJgBIgbAAg");
	this.shape_11.setTransform(239.3,11.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhCAAIAAAZIA6AAIAAAYIg6AAIAAAaIBDAAIAAAZg");
	this.shape_12.setTransform(226,11.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAaA/IAAgzIgyAAIAAAzIgcAAIAAh9IAcAAIAAAyIAyAAIAAgyIAbAAIAAB9g");
	this.shape_13.setTransform(212.2,11.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAcBAIgchSIgcBSIgYAAIgqh+IAdAAIAaBUIAdhVIAWAAIAdBVIAahUIAdAAIgsB+g");
	this.shape_14.setTransform(194.7,11.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhDAAIAAAZIA7AAIAAAYIg7AAIAAAaIBEAAIAAAZg");
	this.shape_15.setTransform(172.1,11.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAWA/IgagpIgWAAIAAApIgcAAIAAh9IA5AAQAJAAANADQAJADAGAHQAFAFADAIQACAHABAIIAAABQgBAIgBAGQgCAGgEAEIgJAIIgKAGIAeAtgAgagBIAbAAIAJgBIAHgEQADgCABgEQABgDABgDIAAgBQgBgFgBgDIgEgGIgHgDIgJgBIgbAAg");
	this.shape_16.setTransform(159.1,11.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAmA/IgMgcIg0AAIgMAcIgcAAIA2h+IAZAAIA2B+gAAQALIgQgoIgQAoIAgAAg");
	this.shape_17.setTransform(144.4,11.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgGBAIgMgEIgLgGIgKgIIgIgJIgFgLQgDgGgBgHIgBgMIAAgBIABgMQABgHADgFIAFgLIAIgKIAKgIIALgGIANgEIAMgBQAJAAAIACQAHAAAGADQAIADAMAMIgRAUQgIgHgHgEQgJgEgJAAQgHABgGADQgHADgFAFQgFAGgDAGQgCAIAAAHIAAAAQAAAIACAIQADAGAFAGQAFAGAGADQAHACAHAAQAIAAALgDQAGgDAIgIIASASIgKAJQgGAEgGADQgGADgHACQgIABgJAAIgMgBg");
	this.shape_18.setTransform(130.2,11.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAWA/IgagpIgWAAIAAApIgbAAIAAh9IA4AAQAIAAAOADQAIADAHAHQAFAFADAIQADAHAAAIIAAABQAAAIgCAGQgCAGgDAEIgJAIIgLAGIAeAtgAgagBIAbAAIAJgBIAHgEQADgCABgEQABgDAAgDIAAgBQAAgFgBgDIgEgGIgHgDIgJgBIgbAAg");
	this.shape_19.setTransform(110.7,11.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWA9IgKgFIgIgGIgFgIQgDgEgCgFIgDgMIgBgNIAAhHIAcAAIAABGQAAAIABAGQACAFAEAEQADAFAGABQAFACAFAAQAHAAAEgCQAFgCAEgDQAEgEACgGQABgFAAgIIAAhHIAcAAIAABGIgBANIgDAMIgFAKIgGAIIgIAGIgKAFQgOADgIAAQgQgBgGgCg");
	this.shape_20.setTransform(96.3,11.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgNBAIgNgEIgLgGIgKgIQgEgEgEgFIgGgLQgCgGgBgHIgCgMIAAgBIACgMQABgHACgFIAGgLIAIgKIAKgIIALgGIANgEIANgBIAOABIANAEIALAGIAKAIQAEAEAEAGIAGALIADALQACAHAAAGIAAAAQAAAGgCAHQgBAGgCAHIgGALIgIAJIgKAIIgMAGIgMAEIgOABIgNgBgAgPgjQgHADgFAFQgEAGgDAGQgDAIAAAHIAAAAQAAAIADAIQADAGAEAGQAGAGAHADQAHACAHAAQAIAAAIgCQAGgDAFgGQAFgGADgGQADgIAAgHIAAgBQAAgHgDgIQgDgGgFgGQgFgFgHgDQgHgDgIgBQgHABgIADg");
	this.shape_21.setTransform(81.2,11.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNA/IAAgyIgwhLIAgAAIAdAyIAfgyIAfAAIgwBLIAAAyg");
	this.shape_22.setTransform(66.4,11.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgvA/IAAh9IBeAAIAAAZIhCAAIAAAZIA6AAIAAAYIg6AAIAAAaIBDAAIAAAZg");
	this.shape_23.setTransform(47.6,11.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAYA/Igmg1IgPAPIAAAmIgcAAIAAh9IAcAAIAAA3IAyg3IAiAAIg0A2IA3BHg");
	this.shape_24.setTransform(34.8,11.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAmA/IgMgcIg0AAIgMAcIgcAAIA2h+IAZAAIA2B+gAAQALIgQgoIgQAoIAgAAg");
	this.shape_25.setTransform(19.8,11.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgNA/IAAhjIgmAAIAAgaIBnAAIAAAaIgmAAIAABjg");
	this.shape_26.setTransform(7.8,11.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1a, new cjs.Rectangle(0,1,392.2,22), null);


(lib.redbg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84639").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.redbg, new cjs.Rectangle(0,0,300,250), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAfIAAgZIgYglIAQAAIAOAaIAPgaIAQAAIgYAlIAAAZg");
	this.shape.setTransform(124.6,6.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AALAfIgMgUIgLAAIAAAUIgOAAIAAg+IAcAAIAKACQAFACADADQADADABADIABAJIgBAGIgCAFIgFAEIgFADIAPAWgAgMAAIANAAIAEAAIAEgDIACgCIAAgEIAAgEIgDgCIgDgCIgFgBIgMAAg");
	this.shape_1.setTransform(118.4,6.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAgIgGgOIgaAAIgFAOIgOAAIAag/IAMAAIAbA/gAAIAFIgIgTIgHATIAPAAg");
	this.shape_2.setTransform(111.4,6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_3.setTransform(104.9,6.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_4.setTransform(100.5,6.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAg+IAOAAIAAAyIAfAAIAAAMg");
	this.shape_5.setTransform(96.5,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_6.setTransform(92,6.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIAQgbIAQAAIAAA+g");
	this.shape_7.setTransform(86.6,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAcAAIAAALIgcAAIAAANIAhAAIAAAMg");
	this.shape_8.setTransform(77.1,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AANAfIAAgZIgZAAIAAAZIgOAAIAAg+IAOAAIAAAaIAZAAIAAgaIAOAAIAAA+g");
	this.shape_9.setTransform(70.6,6.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_10.setTransform(64.3,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAuAAIAAANIggAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_11.setTransform(45.7,6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAfIgdgmIAAAmIgOAAIAAg+IANAAIAdAnIAAgnIANAAIAAA+g");
	this.shape_12.setTransform(39,6.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_13.setTransform(33.9,6.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgCAgIgHgCIgGgDIgEgEIgEgEIgDgGIgBgGIgBgHIABgFIABgHIADgFIAEgFIAEgEIAHgDIAGgCIAFgBIAIABIAHACIAKAHIgJAKQgDgDgEgCQgEgCgFAAQgDAAgDACQgDABgCADIgFAGIgBAHQAAAEABAEIAFAGIAFAEQADACADAAQAEAAAFgCIAIgGIAJAJIgFAFIgGADIgHADIgIAAIgFAAg");
	this.shape_14.setTransform(29.2,6.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_15.setTransform(24.3,6.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAfIAAg+IAYAAIAHABIAGACIAGADIAFADIADAFIAEAFIACAHIAAAFIAAAGIgCAGIgEAGIgDAEIgFAEIgGADIgGACIgHAAgAgOATIAKAAQAEAAADgBQAEgBADgDIADgGQACgDgBgFQABgDgCgDQgBgEgCgDIgHgDQgDgCgEAAIgKAAg");
	this.shape_16.setTransform(19.5,6.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_17.setTransform(13,6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIARgbIAPAAIAAA+g");
	this.shape_18.setTransform(5.9,6.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAgQgNgNAAgTQAAgSANgNQANgNASAAQATAAANANQANANAAASQAAATgNANQgNANgTAAQgSAAgNgNgAgaAKIATAAIAAATIAQAAIAAgTIATAAIAAgSIgTAAIAAgTIgQAAIAAATIgTAAg");
	this.shape_19.setTransform(55.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,130,13), null);


(lib.imgmask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84639").s().p("A0THCIAAuDMAonAAAIAAODg");
	this.shape.setTransform(130,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgmask, new cjs.Rectangle(0,0,260,90), null);


(lib.Humanitarian2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Humanitarian2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Humanitarian2_1, new cjs.Rectangle(0,0,600,400), null);


(lib.Humanitarian1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Humanitarian1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Humanitarian1_1, new cjs.Rectangle(0,0,600,400), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// LEARN MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACLAeIgHgCIgFgCIgFgEIgDgFIgDgFIgCgGIAAgGIAAAAIAAgFIACgGIADgFIAEgFIAFgDIAEgDIAHgCIAGgBIAHABIAGACIAFADIAEADIAFAFIACAFIABAGIABAFIgBAGIgBAGIgDAFIgEAFIgEADIgFADIgHACIgGABIgGgBgACJgTIgGAFQgDADgBAEIgCAHQAAAEACAEIAEAHQACADAEABQAEACAEAAQAEAAAFgCQADgBACgDQADgDACgEIACgIIAAAAIgCgHQgCgEgDgDQgCgDgEgBQgEgCgEAAQgFAAgDABgAD9AeIAAg7IAsAAIAAAKIgiAAIAAAPIAeAAIAAAIIgeAAIAAAQIAiAAIAAAKgADlAeIgQgVIgMAAIAAAVIgLAAIAAg7IAbAAIAKACQAEABADADIAEAGQABADAAAEQAAAEgBADIgDAEIgFAEIgGACIAQAXgADJAAIAPAAIAFAAIAEgCIADgDIAAgEIAAgFIgDgDIgEgCIgFAAIgPAAgABZAeIAAgqIgSAbIgBAAIgSgbIAAAqIgLAAIAAg7IAMAAIASAcIASgcIALAAIAAA7gAgKAeIgggqIAAAqIgLAAIAAg7IAKAAIAfAoIAAgoIALAAIAAA7gAhNAeIgPgVIgNAAIAAAVIgKAAIAAg7IAaAAIAKACQAEABADADIAEAGQABADAAAEQAAAEgBADIgCAEIgFAEIgGACIAQAXgAhpAAIAPAAIAFAAIAEgCIADgDIABgEIgBgFIgDgDIgEgCIgFAAIgPAAgAiKAeIgGgPIgcAAIgGAPIgLAAIAag7IAKAAIAaA7gAiUAGIgKgXIgKAXIAUAAgAjyAeIAAg7IAsAAIAAAKIghAAIAAAPIAdAAIAAAIIgdAAIAAAQIAhAAIAAAKgAkoAeIAAg7IALAAIAAAxIAfAAIAAAKg");
	this.shape.setTransform(0.1,-0.6,1.315,1.315);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BUTTON
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2383A8").s().p("Al3BjQgpAAgdgdQgdgdAAgpQAAgoAdgdQAdgdApAAILvAAQApAAAdAdQAdAdAAAoQAAApgdAdQgdAdgpAAg");
	this.shape_1.setTransform(0,0,1.315,1.315);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-62.5,-13,125,26.1), null);


(lib.bigBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,150,1,1.2);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mainimg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_334 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(334).call(this.frame_334).wait(1));

	// Technology-2
	this.instance = new lib.Humanitarian2_1();
	this.instance.parent = this;
	this.instance.setTransform(112.1,125.1,0.626,0.627,0,0,0,300.2,199.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:148.1},334,cjs.Ease.quadOut).wait(1));

	// Technology-1
	this.instance_1 = new lib.Humanitarian1_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(115.1,125.1,0.626,0.627,0,0,0,300.2,199.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:163.1},334,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76,0,378.9,250.6);


// stage content:
(lib.MedPlus_Banner_everywhere_728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		// Enable mouse interaction with the stage 
		stage.enableMouseOver();
		
		// Define variables used in the 
		var root = this;
		var bigBtn = root.bigBtn;
		var cta = root.cta;
		var legalBtn = root.legalBtn;
		var legalPop = root.legalPop;
		
		// Add event listeners
		bigBtn.addEventListener("click", clickTag);
		bigBtn.addEventListener("mouseover", rollOver);
		bigBtn.addEventListener("mouseout", rollOut);
		/*
		legalBtn.addEventListener("click", legalUp);
		legalPop.addEventListener("click", legalDown);
		*/
		// Define functions to use throughout 
		function rollOver(){
			TweenMax.to(cta, .25, {scaleX:1.1, scaleY:1.1}); 
		};
		
		function rollOut(){
			TweenMax.to(cta, .25, {scaleX:1, scaleY:1});
		};
		
		function clickTag() {
			window.open(window.clickTag);
		}
		/*
		function legalUp(){
			TweenMax.to(legalPop, .5, {y:0, ease: Power1.easeOut}); 
		};
		
		function legalDown(){
			TweenMax.to(legalPop, .5, {y:250, ease: Power1.easeOut}); 
		};
		*/
	}
	this.frame_245 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(244).call(this.frame_245).wait(1));

	// bigBtn
	this.bigBtn = new lib.bigBtn();
	this.bigBtn.parent = this;
	this.bigBtn.setTransform(0,0,2.427,0.3);
	new cjs.ButtonHelper(this.bigBtn, 0, 1, 2, false, new lib.bigBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bigBtn).wait(246));

	// cta
	this.cta = new lib.cta();
	this.cta.parent = this;
	this.cta.setTransform(401.5,66.6);
	this.cta.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(235).to({scaleX:0.04,scaleY:0.04,x:401.4,y:66.5,alpha:1},0).to({scaleX:1,scaleY:1,x:401.5,y:66.6},10,cjs.Ease.backOut).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(12.6,80.3,1.468,1.468,0,0,0,0,13.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(246));

	// txt-line-2a
	this.instance_1 = new lib.txtline2a();
	this.instance_1.parent = this;
	this.instance_1.setTransform(81,18.9,1,1,0,0,0,68.5,8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(195).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2b
	this.instance_2 = new lib.txtline2b();
	this.instance_2.parent = this;
	this.instance_2.setTransform(77.7,45.1,1,1,0,0,0,64.5,8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(195).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-1a
	this.instance_3 = new lib.txtline1a();
	this.instance_3.parent = this;
	this.instance_3.setTransform(72.7,18.9,1,1,0,0,0,60,8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(35).to({_off:false},0).to({alpha:1},8).wait(122).to({alpha:0},8).wait(73));

	// txt-line-1b
	this.instance_4 = new lib.txtline1b();
	this.instance_4.parent = this;
	this.instance_4.setTransform(63.7,38.9,1,1,0,0,0,51,8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(35).to({_off:false},0).to({alpha:1},8).wait(122).to({alpha:0},8).wait(73));

	// txt-line-1c
	this.instance_5 = new lib.txtline1c();
	this.instance_5.parent = this;
	this.instance_5.setTransform(273,72.1,1,1,0,0,0,49.1,8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(90).to({_off:false},0).to({alpha:1},8).wait(67).to({alpha:0},8).wait(73));

	// img-mask
	this.instance_6 = new lib.redbg();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,0,1.58,0.36);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(5).to({_off:false},0).wait(241));

	// img-mask-reveal
	this.instance_7 = new lib.imgmask();
	this.instance_7.parent = this;
	this.instance_7.setTransform(468,45,1,1,0,0,0,0,45);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:728},25,cjs.Ease.quadOut).wait(216));

	// main-img
	this.instance_8 = new lib.mainimg();
	this.instance_8.parent = this;
	this.instance_8.setTransform(445.7,-67.7,0.832,0.832,0,0,0,-59.1,-0.3);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(5).to({_off:false},0).wait(241));

	// red-bg
	this.instance_9 = new lib.redbg();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,2.427,0.36);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(246));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,728,90);
// library properties:
lib.properties = {
	id: '921C301E2A774CFD85816EFEBF3EA78D',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/MedPlus_Banner_everywhere_728x90_atlas_.png?1506107539951", id:"MedPlus_Banner_everywhere_728x90_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['921C301E2A774CFD85816EFEBF3EA78D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;