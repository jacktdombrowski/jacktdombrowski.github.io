(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Flight_Surgeon = function() {
	this.initialize(img.Flight_Surgeon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,840);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtline2e = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMANIAAgZIAZAAIAAAZg");
	this.shape.setTransform(71,1091.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA4IAAgsIgrhDIAcAAIAaAtIAbgtIAcAAIgrBCIAAAtg");
	this.shape_1.setTransform(64.4,1087.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAUA4IgXgkIgUAAIAAAkIgYAAIAAhvIAyAAQAHAAAMADQAIADAGAFQAEAFADAGQACAHAAAIIAAABQAAAGgCAFQgBAGgEADIgHAIQgEADgGACIAbAogAgXAAIAYAAIAIgBIAGgEQADgCABgDQABgDAAgDQAAgFgBgDQgBgCgDgCIgGgEQgEgBgEAAIgYAAg");
	this.shape_2.setTransform(53.3,1087.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA5IgLgZIguAAIgKAZIgZAAIAwhxIAVAAIAwBxgAAOAJIgOgjIgOAjIAcAAg");
	this.shape_3.setTransform(40.9,1087.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLA4IAAhZIgiAAIAAgWIBbAAIAAAWIgiAAIAABZg");
	this.shape_4.setTransform(29.4,1087.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_5.setTransform(21.5,1087.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgnA4IAAhvIAYAAIAABZIA3AAIAAAWg");
	this.shape_6.setTransform(14.3,1087.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_7.setTransform(6.3,1087.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAfA4IAAhIIgfAuIAAAAIgfguIAABIIgYAAIAAhvIAbAAIAcAvIAdgvIAbAAIAABvg");
	this.shape_8.setTransform(-3.3,1087.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAXIAzAAIAAAUIgzAAIAAAYIA8AAIAAAWg");
	this.shape_9.setTransform(-20.1,1087.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXA4IAAgtIgtAAIAAAtIgYAAIAAhvIAYAAIAAAtIAtAAIAAgtIAYAAIAABvg");
	this.shape_10.setTransform(-31.8,1087.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLA4IAAhZIgiAAIAAgWIBbAAIAAAWIgiAAIAABZg");
	this.shape_11.setTransform(-43.1,1087.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2e, new cjs.Rectangle(-50.2,1078,125.7,20), null);


(lib.txtline2d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdA4Ig2hGIAABGIgYAAIAAhvIAXAAIAzBEIAAhEIAZAAIAABvg");
	this.shape.setTransform(86.6,10.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_1.setTransform(77.4,10.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJA5QgGgCgGgCQgGgCgGgDQgGgEgEgFIAOgRQAIAHAIADIAIADIAJABQAHAAAEgDQAFgDAAgFIAAAAQAAgFgFgCQgEgEgNgDIgPgFQgHgDgFgDQgFgDgCgFQgDgGAAgJIAAAAQAAgHADgHQADgGAFgFQAFgEAHgCQAIgCAIgBIALABIALADIAKAEIAJAHIgNASIgPgIQgHgDgGAAQgHAAgEADQgEADAAAEQAAAFAFAEQAFACAOAEIAPAFQAHADAEADQAFAEACAFQACAGAAAGIAAABQAAAIgDAHQgDAGgFAFQgGAEgHADQgIABgJAAIgMAAg");
	this.shape_2.setTransform(64.3,10.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAUA4IgXgkIgUAAIAAAkIgYAAIAAhvIAyAAQAHAAAMADQAIADAGAGQAEAEADAHQACAGAAAIIAAABQAAAGgCAGQgBAFgEAEIgHAHQgEADgGACIAbAogAgXgBIAYAAIAIgBIAGgDQADgCABgDQABgDAAgDQAAgFgBgCQgBgEgDgCIgGgDQgEgBgEAAIgYAAg");
	this.shape_3.setTransform(53.7,10.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAWIAzAAIAAAWIgzAAIAAAXIA8AAIAAAWg");
	this.shape_4.setTransform(42.3,10.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAWIAzAAIAAAWIgzAAIAAAXIA8AAIAAAWg");
	this.shape_5.setTransform(31.4,10.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUA4IgXgkIgUAAIAAAkIgYAAIAAhvIAyAAQAHAAAMADQAIADAGAGQAEAEADAHQACAGAAAIIAAABQAAAGgCAGQgBAFgEAEIgHAHQgEADgGACIAbAogAgXgBIAYAAIAIgBIAGgDQADgCABgDQABgDAAgDQAAgFgBgCQgBgEgDgCIgGgDQgEgBgEAAIgYAAg");
	this.shape_6.setTransform(20.2,10.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAiA4IgLgYIguAAIgKAYIgZAAIAwhvIAVAAIAwBvgAAOAJIgOgjIgOAjIAcAAg");
	this.shape_7.setTransform(7.5,10.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgFA5IgLgDQgFgDgFgDQgFgDgDgEQgEgEgDgFIgFgJIgEgLIgBgLIAAgBIABgLIADgLIAGgKIAHgIQADgEAFgDIAKgFIALgEQAFgBAHAAQAHAAAHABQAGABAGADQAHADALAJIgQASQgHgGgGgDQgHgDgJAAQgGAAgGACQgFADgFAFQgEAFgDAGQgCAGAAAHIAAAAQAAAHACAGQADAHAEAFQAEAFAGACQAGADAGAAQAHAAAKgEQAGgCAHgHIAQAQQgFAFgEADQgFAEgGACIgMAFQgGABgIAAIgLgBg");
	this.shape_8.setTransform(-4.8,10.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2d, new cjs.Rectangle(-12.8,1.3,108.1,20), null);


(lib.txtline2c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnA4IAAhvIAYAAIAABYIA3AAIAAAXg");
	this.shape.setTransform(65.4,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAiA4IgLgYIguAAIgKAYIgZAAIAwhvIAVAAIAwBvgAAOAJIgOgjIgOAjIAcAAg");
	this.shape_1.setTransform(53.6,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFA5IgLgDQgFgCgFgEQgFgDgDgEQgEgDgDgGIgFgJIgEgLIgBgLIAAgBIABgLIADgLIAGgKIAHgIQADgEAFgDIAKgFIALgEQAFgBAHAAQAHAAAHABQAGACAGACQAHADALAJIgQASQgHgGgGgDQgHgDgJAAQgGAAgGACQgFADgFAFQgEAFgDAGQgCAGAAAHIAAAAQAAAHACAGQADAHAEAFQAEAFAGACQAGADAGAAQAHAAAKgEQAGgCAHgHIAQAQIgJAIQgFAEgGADIgMADQgGACgIAAIgLgBg");
	this.shape_2.setTransform(41.4,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_3.setTransform(32.6,9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgyA4IAAhvIArAAIAMABQAGABAFACIAKAGQAFACAEAEIAHAIIAGAJIACALIABALIAAAAIgBALIgCALIgGAJIgHAJIgJAHIgKAEQgFADgGABIgMABgAgaAhIATAAQAHAAAGgCQAGgCAEgFQAFgEACgGQADgHAAgGIAAgBQAAgGgDgHQgCgGgFgFQgEgEgGgDQgGgCgHAAIgTAAg");
	this.shape_4.setTransform(23.9,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAWIAzAAIAAAWIgzAAIAAAXIA8AAIAAAWg");
	this.shape_5.setTransform(12.2,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgA4IAAhIIggAuIAAAAIgfgtIAABHIgYAAIAAhvIAaAAIAdAwIAegwIAaAAIAABvg");
	this.shape_6.setTransform(-0.4,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2c, new cjs.Rectangle(-9.4,0,81.6,20), null);


(lib.txtline2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGA5IgLgEIgKgEIgJgIIgHgIIgFgJIgDgLIgBgNIAAAAIABgLIADgKIAFgKIAHgJIAJgHIAKgGIALgDIALgBIAOABIAMADQAHACALAKIgPASQgHgFgGgDQgHgDgJAAQgGAAgGADQgGACgEAFQgFAFgCAGQgDAHAAAGIAAAAQAAAHADAHQACAHAFAEQAFAFAGADQAGACAGAAQAHAAAGgBIALgFIAAgQIgZAAIAAgVIAwAAIAAAwQgMAKgIACIgNAFQgHABgHAAIgMgBg");
	this.shape.setTransform(71.1,8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdA4Ig2hGIAABGIgYAAIAAhvIAXAAIAzBEIAAhEIAZAAIAABvg");
	this.shape_1.setTransform(58.7,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_2.setTransform(49.7,8.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLA4IAAhYIgiAAIAAgXIBbAAIAAAXIgiAAIAABYg");
	this.shape_3.setTransform(41.8,8.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_4.setTransform(34,8.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgFA5IgLgEQgFgCgFgDQgFgDgDgEQgEgEgDgFIgFgJIgEgLIgBgMIAAAAIABgLIADgKIAGgKIAHgJQADgEAFgDIAKgGIALgDQAFgBAHAAQAHAAAHABQAGACAGACQAHADALAKIgQASQgHgHgGgDQgHgDgJAAQgGAAgGADQgFACgFAFQgEAFgDAGQgCAHAAAGIAAAAQAAAHACAHQADAGAEAFQAEAFAGACQAGADAGAAQAHAAAKgDQAGgDAHgHIAQAQIgJAIQgFAEgGACIgMAFQgGABgIAAIgLgBg");
	this.shape_5.setTransform(25.5,8.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAZA4IgZgnIgZAnIgcAAIAog4Igmg3IAdAAIAWAkIAYgkIAcAAIglA2IAmA5g");
	this.shape_6.setTransform(13.7,8.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAWIAzAAIAAAWIgzAAIAAAXIA8AAIAAAWg");
	this.shape_7.setTransform(2.7,8.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2b, new cjs.Rectangle(-4.9,-0.7,84.6,20), null);


(lib.txtline2a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAUA4IgXgkIgUAAIAAAkIgYAAIAAhvIAyAAQAHAAAMADQAIADAGAFQAEAFADAGQACAHAAAIIAAAAQAAAHgCAFQgBAGgEADIgHAIQgEADgGACIAbAogAgXAAIAYAAIAIgBIAGgEQADgCABgDQABgDAAgEQAAgDgBgEQgBgDgDgBIgGgEQgEgBgEAAIgYAAg");
	this.shape.setTransform(75.3,5.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgqA4IAAhvIBUAAIAAAWIg7AAIAAAXIAzAAIAAAUIgzAAIAAAYIA8AAIAAAWg");
	this.shape_1.setTransform(64.1,5.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKA5IgthxIAbAAIAcBOIAehOIAaAAIgtBxg");
	this.shape_2.setTransform(52.5,5.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLA5IgMgDIgKgGIgJgHIgHgIIgFgKQgCgGgBgFIgCgMIAAAAIACgKIADgLIAGgLIAGgIIAJgHIAKgGIAMgCIALgCQAGAAAGACIAMACQAGACAEAEIAJAHIAHAIIAFALIAEAKIABALIAAAAIgBALIgEAMIgFAKIgHAIIgJAHIgKAGIgMACIgMACIgLgBgAgNggQgGADgFAFQgEAFgCAGQgDAGAAAHIAAAAQAAAHADAHQACAGAFAFQAEAFAHADQAGACAGAAQAIAAAGgCQAGgDAFgFQAEgFADgGQACgGAAgIIAAAAQAAgGgDgGQgCgHgEgFQgGgFgFgDQgHgCgHAAQgHAAgGACg");
	this.shape_3.setTransform(39.7,5.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgFA5IgLgDQgFgDgFgDQgFgDgDgEQgEgDgDgFIgFgKIgEgLIgBgMIAAAAIABgKIADgLIAGgLIAHgIQADgEAFgDIAKgGIALgCQAFgCAHAAQAHAAAHACQAGAAAGADQAHADALAKIgQASQgHgHgGgDQgHgDgJAAQgGAAgGACQgFADgFAFQgEAFgDAGQgCAGAAAHIAAAAQAAAHACAHQADAGAEAFQAEAFAGADQAGACAGAAQAHAAAKgDQAGgDAHgHIAQAQIgJAIQgFAEgGADIgMADQgGACgIAAIgLgBg");
	this.shape_4.setTransform(27.1,5.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgJA4QgGAAgGgDQgGgCgGgEQgGgDgEgFIAOgQQAIAGAIADIAIADIAJABQAHAAAEgDQAFgDAAgEIAAgBQAAgFgFgDQgEgDgNgEIgPgEQgHgCgFgEQgFgDgCgFQgDgGAAgJIAAAAQAAgIADgFQADgHAFgEQAFgFAHgCQAIgCAIAAIALABIALACIAKAFIAJAFIgNATQgIgFgHgDQgHgDgGAAQgHAAgEADQgEACAAAFQAAAFAFADQAFADAOAEIAPAFQAHADAEACQAFAEACAGQACAFAAAIIAAAAQAAAIgDAGQgDAHgFAEQgGAFgHACQgIACgJAAIgMgBg");
	this.shape_5.setTransform(15.9,5.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLA4IAAhvIAXAAIAABvg");
	this.shape_6.setTransform(8.2,5.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgzA4IAAhvIAsAAIAMABQAGABAGACIAKAGIAIAGIAHAIIAFAKIAEALIABAKIAAAAIgBALIgEALIgFAKIgHAIIgIAGIgKAGQgGACgGABIgMABgAgaAiIATAAQAHAAAGgCQAGgDAFgEQAEgFADgGQACgGAAgIIAAAAQAAgHgCgFQgDgHgEgFQgFgEgGgCQgGgDgHAAIgTAAg");
	this.shape_7.setTransform(-0.5,5.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2a, new cjs.Rectangle(-9,-3.7,91.9,20), null);


(lib.txtline1e = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOA1IAAgYIAXAAIAAAYgAgJASIgDgYIABAAIALgCQAFgBACgCQADgBACgDQABgCABgDQgBgGgDgCQgEgDgGAAQgGAAgFACQgGADgEAFIgPgPIAHgHIAJgFIAKgDQAGgBAEAAQAJAAAGACQAHACAEAEQAFAEADAGQACAGAAAHIAAAAQAAAHgCAGQgCAFgEADQgEADgGACQgFACgGABIgBAKg");
	this.shape.setTransform(88.9,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAbA0IgyhBIAABBIgXAAIAAhoIAWAAIAwBAIAAhAIAXAAIAABog");
	this.shape_1.setTransform(78.2,9.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLA1IgLgDIgJgFIgIgGIgHgIIgFgJIgDgLIgBgLIAAAAIABgKIADgKIAFgJIAHgIIAIgHIAKgFIAKgDIALgCQAGABAGABIALADIAJAFIAIAHIAHAIIAFAJIADAKIABAKIAAAAIgBALIgDAKIgFAKIgHAIIgIAGIgKAFIgKADIgMABQgFAAgGgBgAgMgdQgGACgEAFQgEAEgCAGQgDAGAAAGIAAAAQAAAGADAHQACAGAEAFQAFAEAFADQAGACAGAAQAHAAAGgCQAGgDAEgEQAEgFACgGQADgGAAgHIAAAAQAAgGgDgGQgCgFgEgFQgFgFgFgCQgGgDgHAAQgGAAgGADg");
	this.shape_2.setTransform(65.1,9.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnA0IAAhoIBOAAIAAAVIg3AAIAAAVIAxAAIAAAUIgxAAIAAAWIA4AAIAAAUg");
	this.shape_3.setTransform(53.2,9.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgFA1IgLgDQgGgBgDgEIgIgGQgEgDgDgFIgFgJIgDgKIgBgMIAAAAIABgKIADgKIAFgJIAHgIIAIgHIAJgFIALgDQAFgBAFgBIANABIALAEQAGACALAIIgPASQgGgGgFgCQgHgDgJAAQgFAAgFADQgGACgEAFQgFAEgCAGQgCAGAAAGIAAAAQAAAHACAHQADAFAEAFQAFAFAFACQAGACAGAAQAGAAAGgBQAFgCAFgDIAAgPIgYAAIAAgTIAuAAIAAAsQgMAKgIADQgFACgGABIgOABQgFAAgFgBg");
	this.shape_4.setTransform(41.2,9.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AATA0IgWghIgTAAIAAAhIgWAAIAAhoIAuAAQAIABAKADQAIACAFAFQAEAEADAHQACAGAAAHIAAAAQAAAHgCAFQgBAFgDADIgHAHQgEADgGACIAbAlgAgWgBIAXAAIAIgBQADAAACgCQADgCABgEQABgCAAgEQAAgEgBgCQgBgDgDgCQgDgCgDAAIgHgBIgXAAg");
	this.shape_5.setTransform(29.6,9.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSAyIgIgDIgHgFIgFgHIgEgIIgCgJIgBgLIAAg7IAXAAIAAA6QAAAGACAFQABAFADAEQADADAEABQAFACAEAAQAFAAAEgBQAFgCADgDIAEgIQACgFAAgGIAAg7IAXAAIAAA6IgBALQgBAFgCAFIgDAIIgGAHIgGAFIgIADQgMADgHAAQgNgBgFgCg");
	this.shape_6.setTransform(17.3,9.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIA1IgMgDIgLgGQgFgDgFgEIAOgQQAIAGAHADIAIADIAHAAQAIAAADgCQAFgDAAgEQAAgFgFgDQgEgDgMgDIgOgEIgLgGQgFgDgCgFQgDgGAAgHIAAAAQABgIADgGQACgFAFgFQAFgDAHgCQAGgDAIAAIALABIAKADIAJADIAJAHIgMARQgIgFgHgDQgHgCgFAAQgGAAgEACQgDADgBAEIAAAAQABAFAEACQAEADANADIAOAGQAGACAFACQAEAFACAEQACAGAAAGIAAABQAAAHgCAGQgDAHgFADQgFAEgHADQgIACgIAAIgLgBg");
	this.shape_7.setTransform(6,9.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1e, new cjs.Rectangle(-0.7,0.5,96.9,19), null);


(lib.txtline1d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLA0IAAhSIgfAAIAAgWIBWAAIAAAWIggAAIAABSg");
	this.shape.setTransform(107.8,11.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVA0IAAgqIgqAAIAAAqIgWAAIAAhoIAWAAIAAAqIAqAAIAAgqIAYAAIAABog");
	this.shape_1.setTransform(96.4,11.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFA1IgMgDQgEgBgFgEIgIgGQgEgDgCgFIgFgJIgDgKIgBgMIAAAAIABgKIADgKIAFgJIAGgIIAIgHIAKgFIALgDQAFgBAFgBIANABIAKAEQAHACALAIIgOASQgHgGgGgCQgGgDgIAAQgGAAgGADQgFACgEAFQgEAEgCAGQgDAGAAAGIAAAAQAAAHADAHQACAFAEAFQAFAFAFACQAGACAGAAQAGAAAFgBQAHgCADgDIAAgPIgWAAIAAgTIAtAAIAAAsQgMAKgHADQgGACgGABIgOABQgFAAgFgBg");
	this.shape_2.setTransform(84,11.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLA0IAAhoIAXAAIAABog");
	this.shape_3.setTransform(74.9,11.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AglA0IAAhoIAXAAIAABUIA0AAIAAAUg");
	this.shape_4.setTransform(67.3,11.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgnA0IAAhoIBPAAIAAAWIg4AAIAAAWIAxAAIAAAUIgxAAIAAAog");
	this.shape_5.setTransform(57,11.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAfA1IgJgYIgrAAIgKAYIgYAAIAthpIAVAAIAtBpgAAOAJIgOghIgNAhIAbAAg");
	this.shape_6.setTransform(39.7,11.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnA0IAAhoIBPAAIAAAVIg4AAIAAAVIAxAAIAAAUIgxAAIAAAWIA4AAIAAAUg");
	this.shape_7.setTransform(22.9,11.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgsA0IAAhoIAwAAQAJAAAHADQAHACAFAFQADAEACAEQACAEAAAFIAAABIgBAIIgDAGQgEAFgGADIAIADIAGAGIAEAHQACAEAAAGQAAAHgDAFQgDAGgFADQgFAEgIACQgHABgJAAgAgVAhIAaAAQAIAAAEgDQAFgDAAgGIAAAAQAAgGgEgDIgGgCIgHgBIgaAAgAgVgJIAVAAQAHAAAEgCQAFgDAAgGIAAAAQAAgFgEgDQgEgDgHAAIgWAAg");
	this.shape_8.setTransform(11.7,11.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1d, new cjs.Rectangle(4,2.8,111.6,19), null);


(lib.txtline1c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbA1IgyhCIAABCIgXAAIAAhoIAWAAIAwA/IAAg/IAXAAIAABog");
	this.shape.setTransform(123,13.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfA1IgJgYIgrAAIgKAYIgYAAIAthpIAVAAIAtBpgAAOAJIgOghIgNAhIAbAAg");
	this.shape_1.setTransform(110.3,13.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFA1IgKgDIgJgFIgIgGQgEgEgDgFIgEgJIgEgKIgBgKIAAgBIABgKIAEgKIAEgKIAHgIIAIgGIAJgFIALgDIAKgBQAHAAAHABIALADQAHADAKAJIgPARQgHgGgFgDQgIgDgHAAQgGAAgFACQgFADgFAEQgEAFgCAGQgDAGABAGIAAAAQgBAHADAFQACAHAEAEQAEAFAGACQAFADAGAAQAGAAAJgEQAGgCAGgGIAPAPIgIAIIgJAFQgGADgGABQgGABgIABQgFgBgFgBg");
	this.shape_2.setTransform(98.2,13.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgSAyIgIgDIgHgFIgFgHIgEgIIgCgJIgBgLIAAg7IAXAAIAAA6QAAAGACAFQABAFADAEQADADAEABQAFACAEAAQAFAAAEgBQAFgCADgDIAEgIQACgFAAgGIAAg7IAXAAIAAA6IgBALQgBAFgCAFIgDAIIgGAHIgGAFIgIADQgMADgHAAQgNgBgFgCg");
	this.shape_3.setTransform(80.8,13.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLA1IgLgDIgJgFIgIgGIgHgJIgFgJIgDgKIgBgKIAAgBIABgKIADgKIAFgKIAHgIIAIgGIAKgFIAKgDIALgBQAGAAAGABIALADIAJAFIAIAGIAHAIIAFAJIADALIABAKIAAAAIgBALIgDAKIgFAJIgHAJIgIAGIgKAFIgKADIgMACQgFgBgGgBgAgMgeQgGADgEAEQgEAFgCAGQgDAGAAAGIAAAAQAAAHADAFQACAHAEAEQAFAFAFACQAGADAGAAQAHAAAGgDQAGgCAEgFQAEgEACgGQADgGAAgGIAAgBQAAgGgDgGQgCgGgEgEQgFgFgFgDQgGgCgHAAQgGAAgGACg");
	this.shape_4.setTransform(68,13.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgLA1IAAgqIgog+IAbAAIAYAqIAagqIAaAAIgoA+IAAAqg");
	this.shape_5.setTransform(55.5,13.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAbA1IgyhCIAABCIgXAAIAAhoIAWAAIAwA/IAAg/IAXAAIAABog");
	this.shape_6.setTransform(38.1,13.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnA1IAAhoIBPAAIAAAUIg4AAIAAAWIAwAAIAAATIgwAAIAAAWIA4AAIAAAVg");
	this.shape_7.setTransform(26.6,13.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAVA1IAAgqIgpAAIAAAqIgYAAIAAhoIAYAAIAAApIApAAIAAgpIAYAAIAABog");
	this.shape_8.setTransform(14.8,13.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAYA1IgYhEIgXBEIgUAAIgkhoIAZAAIAWBGIAXhHIATAAIAYBHIAVhGIAZAAIgkBog");
	this.shape_9.setTransform(-0.1,13.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1c, new cjs.Rectangle(-10.5,4.5,142.4,19), null);


(lib.txtline1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbA0IgyhBIAABBIgXAAIAAhnIAWAAIAwA/IAAg/IAXAAIAABng");
	this.shape.setTransform(93.2,10);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA1IgLgDIgJgFIgIgGIgHgIIgFgKIgDgKIgBgKIAAgBIABgKIADgKIAFgKIAHgIIAIgGIAKgFIAKgDIALgBQAGAAAGABIALADIAJAFIAIAGIAHAIIAFAJIADALIABAKIAAAAIgBALIgDAKIgFAKIgHAIIgIAGIgKAFIgKADIgMACQgFAAgGgCgAgMgeQgGADgEAFQgEAEgCAGQgDAGAAAGIAAAAQAAAHADAGQACAFAEAFQAFAFAFADQAGACAGAAQAHAAAGgCQAGgDAEgFQAEgEACgGQADgGAAgGIAAgBQAAgFgDgHQgCgGgEgEQgFgFgFgDQgGgCgHAAQgGAAgGACg");
	this.shape_1.setTransform(80.1,10);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnA0IAAhnIBOAAIAAAUIg3AAIAAAVIAwAAIAAAUIgwAAIAAAWIA4AAIAAAUg");
	this.shape_2.setTransform(68.2,10);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFA1IgMgDQgEgBgFgDIgHgHQgEgEgDgEIgFgJIgDgKIgBgLIAAgBIABgKIADgKIAFgKIAHgIIAHgGIAKgFIALgDQAFgBAFAAIANABIALACQAGADALAIIgOARQgHgFgFgCQgHgDgIAAQgGAAgFACQgGADgEAFQgEAEgCAGQgDAGAAAGIAAAAQAAAHADAGQACAGAEAFQAEAEAGADQAGACAGAAQAGAAAFgCQAHgBADgDIAAgPIgWAAIAAgTIAtAAIAAAtQgMAIgHADQgGADgGABIgOACQgFAAgFgCg");
	this.shape_3.setTransform(56.2,10);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AATA0IgWghIgTAAIAAAhIgXAAIAAhnIAwAAQAGAAAMACQAHADAFAFQAEAFADAFQACAHAAAHIAAABQAAAFgCAGQgBAFgDADIgHAHQgEADgFACIAaAlgAgWgBIAXAAIAHgBQAEgBACgCQACgBABgEQACgCAAgDQAAgFgCgCQgBgDgCgCQgDgCgDgBIgHgBIgXAAg");
	this.shape_4.setTransform(44.6,10);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSAyIgIgDIgHgFIgFgHIgEgIIgCgJIgBgLIAAg7IAXAAIAAA6QAAAGACAFQABAFADAEQADADAEABQAFACAEAAQAFAAAEgBQAFgCADgDIAEgIQACgFAAgGIAAg7IAXAAIAAA6IgBALQgBAFgCAFIgDAIIgGAHIgGAFIgIADQgMADgHAAQgNgBgFgCg");
	this.shape_5.setTransform(32.3,10.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgIA1IgMgDIgKgFQgGgDgEgFIANgQQAHAGAIADIAIACIAIABQAHAAAEgCQADgDAAgFQAAgEgDgDQgFgDgMgDIgOgFIgLgFQgFgDgCgFQgCgGgBgHIAAgBQAAgGADgGQADgGAFgEQAFgFAHgBQAHgDAHAAIAKABIALACIAJAEIAJAGIgNASQgHgGgGgCQgIgDgFABQgHgBgDADQgEADABAEIAAAAQgBAFAFADQAFACAMADIAPAFQAFADAFADQAEADADAGQACAFAAAGIAAAAQAAAIgDAHQgDAFgFAFQgGAEgHACQgGACgJAAIgLgBg");
	this.shape_6.setTransform(21,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1b, new cjs.Rectangle(14.3,1.3,87.9,19), null);


(lib.txtline1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfA1IgJgYIgrAAIgKAYIgYAAIAthpIAVAAIAtBpgAAOAJIgOghIgNAhIAbAAg");
	this.shape.setTransform(106,7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnA0IAAhoIBPAAIAAAVIg4AAIAAAVIAwAAIAAAUIgwAAIAAAWIA4AAIAAAUg");
	this.shape_1.setTransform(89.2,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgsA0IAAhoIAwAAQAJAAAHADQAHACAFAFQADAEACAEQACAEAAAFIAAABIgBAIIgDAGQgEAFgGADIAIADIAGAGIAEAHQACAEAAAGQAAAHgDAFQgDAGgFADQgFAEgIACQgHABgJAAgAgVAhIAaAAQAIAAAEgDQAFgDAAgGIAAAAQAAgGgEgDIgGgCIgHgBIgaAAgAgVgJIAVAAQAHAAAEgCQAFgDAAgGIAAAAQAAgFgEgEQgEgCgHAAIgWAAg");
	this.shape_2.setTransform(78.1,7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLA0IAAgpIgog/IAbAAIAYAqIAagqIAaAAIgoA+IAAAqg");
	this.shape_3.setTransform(60.9,7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAWA0IAAgqIgrAAIAAAqIgWAAIAAhoIAWAAIAAAqIArAAIAAgqIAWAAIAABog");
	this.shape_4.setTransform(49.1,7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYA1IgYhDIgXBDIgUAAIgkhpIAZAAIAWBGIAXhGIATAAIAYBGIAVhGIAZAAIgkBpg");
	this.shape_5.setTransform(34.2,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1a, new cjs.Rectangle(23.8,-1.7,91.2,19), null);


(lib.redbg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84639").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.redbg, new cjs.Rectangle(0,0,300,250), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAfIAAgZIgYglIAQAAIAOAaIAPgaIAQAAIgYAlIAAAZg");
	this.shape.setTransform(124.6,6.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AALAfIgMgUIgLAAIAAAUIgOAAIAAg+IAcAAIAKACQAFACADADQADADABADIABAJIgBAGIgCAFIgFAEIgFADIAPAWgAgMAAIANAAIAEAAIAEgDIACgCIAAgEIAAgEIgDgCIgDgCIgFgBIgMAAg");
	this.shape_1.setTransform(118.4,6.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAgIgGgOIgaAAIgFAOIgOAAIAag/IAMAAIAbA/gAAIAFIgIgTIgHATIAPAAg");
	this.shape_2.setTransform(111.4,6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_3.setTransform(104.9,6.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_4.setTransform(100.5,6.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAg+IAOAAIAAAyIAfAAIAAAMg");
	this.shape_5.setTransform(96.5,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_6.setTransform(92,6.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIAQgbIAQAAIAAA+g");
	this.shape_7.setTransform(86.6,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAcAAIAAALIgcAAIAAANIAhAAIAAAMg");
	this.shape_8.setTransform(77.1,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AANAfIAAgZIgZAAIAAAZIgOAAIAAg+IAOAAIAAAaIAZAAIAAgaIAOAAIAAA+g");
	this.shape_9.setTransform(70.6,6.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_10.setTransform(64.3,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAuAAIAAANIggAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_11.setTransform(45.7,6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAfIgdgmIAAAmIgOAAIAAg+IANAAIAdAnIAAgnIANAAIAAA+g");
	this.shape_12.setTransform(39,6.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_13.setTransform(33.9,6.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgCAgIgHgCIgGgDIgEgEIgEgEIgDgGIgBgGIgBgHIABgFIABgHIADgFIAEgFIAEgEIAHgDIAGgCIAFgBIAIABIAHACIAKAHIgJAKQgDgDgEgCQgEgCgFAAQgDAAgDACQgDABgCADIgFAGIgBAHQAAAEABAEIAFAGIAFAEQADACADAAQAEAAAFgCIAIgGIAJAJIgFAFIgGADIgHADIgIAAIgFAAg");
	this.shape_14.setTransform(29.2,6.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_15.setTransform(24.3,6.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAfIAAg+IAYAAIAHABIAGACIAGADIAFADIADAFIAEAFIACAHIAAAFIAAAGIgCAGIgEAGIgDAEIgFAEIgGADIgGACIgHAAgAgOATIAKAAQAEAAADgBQAEgBADgDIADgGQACgDgBgFQABgDgCgDQgBgEgCgDIgHgDQgDgCgEAAIgKAAg");
	this.shape_16.setTransform(19.5,6.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_17.setTransform(13,6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIARgbIAPAAIAAA+g");
	this.shape_18.setTransform(5.9,6.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAgQgNgNAAgTQAAgSANgNQANgNASAAQATAAANANQANANAAASQAAATgNANQgNANgTAAQgSAAgNgNgAgaAKIATAAIAAATIAQAAIAAgTIATAAIAAgSIgTAAIAAgTIgQAAIAAATIgTAAg");
	this.shape_19.setTransform(55.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,130,13), null);


(lib.flightsurgeon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Flight_Surgeon();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.flightsurgeon, new cjs.Rectangle(0,0,600,840), null);


(lib.crosscover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAgMAOIAaAAIAAgbIgaAAg");
	this.shape.setTransform(167.4,167.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAiuCwIFeAAIAAlfIleAAg");
	this.shape_1.setTransform(167.4,167.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAlIFJIKRAAIAAqRIqRAAg");
	this.shape_2.setTransform(167.4,167.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAnZHaQOpACALgBQABgLgBuqIu0AAg");
	this.shape_3.setTransform(167.4,167.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgApiJjQS8ACAKgBQABgKgBy9IzGAAg");
	this.shape_4.setTransform(167.4,167.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgArjLkQW+ACAJgCQACgJgC2+I3HAAg");
	this.shape_5.setTransform(167.4,167.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAtbNcQavACAJgBQABgJgB6wI64AAg");
	this.shape_6.setTransform(167.4,167.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAvLPMQeQADAIgCQACgIgC+RI+YAAg");
	this.shape_7.setTransform(167.4,167.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAwzQ0UAhgAADAAHgADUAADgAHgADghgMghnAAAg");
	this.shape_8.setTransform(167.4,167.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAyTSUUAkgAACAAHgACUAACgAHgACgkgMgknAAAg");
	this.shape_9.setTransform(167.4,167.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAzqTrUAnPAADAAGgADUAADgAGgADgnPMgnVAAAg");
	this.shape_10.setTransform(167.4,167.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA05U6UAptAADAAGgADUAADgAGgADgptMgpzAAAg");
	this.shape_11.setTransform(167.4,167.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA1/WAUAr6AAEAAGgADUAADgAGgADgr7MgsAAAAg");
	this.shape_12.setTransform(167.4,167.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA2+W+UAt4AAEAAFgADUAADgAFgADgt4Mgt9AAAg");
	this.shape_13.setTransform(167.4,167.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA30X0UAvkAAEAAFgADUAADgAFgADgvkMgvpAAAg");
	this.shape_14.setTransform(167.4,167.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA4hYiUAw/AAEAAEgAEUAAEgAEgAEgw/MgxDAAAg");
	this.shape_15.setTransform(167.4,167.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA5HZHUAyLAAEAAEgADUAADgAEgADgyLMgyPAAAg");
	this.shape_16.setTransform(167.4,167.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA5kZkUAzFAAEAAEgADUAADgAEgADgzFMgzJAAAg");
	this.shape_17.setTransform(167.4,167.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA55Z5UAzvAAEAAEgADUAADgAEgADgzvMgzzAAAg");
	this.shape_18.setTransform(167.4,167.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA6FaGUA0IAAEAADgAEUAAEgADgAEg0IMg0LAAAg");
	this.shape_19.setTransform(167.4,167.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA6JaKUA0QAAEAADgAEUAAEgADgAEg0QMg0TAAAg");
	this.shape_20.setTransform(167.4,167.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},4).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-20,374.9,374.9);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// LEARN MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AC3AoIgIgDIgHgDIgGgFIgFgGIgDgHIgDgIIgBgIIAAAAIABgHIADgIIADgHQACgDAEgDIAFgEIAHgEIAIgDIAJgBIAJABIAIADIAGAEIAGAEIAGAGIADAHIACAIIAAAHIAAAIIgCAHIgEAIIgFAGIgGAEIgHAEIgIADIgIABIgJgBgAC1gZIgIAHQgEADgCAFQgCAFAAAFQAAAGACAFQACAEAEAEQAEAEAEACQAFADAGAAQAFAAAGgDQAFgCADgEQADgDADgFQACgFAAgGIAAAAQAAgFgCgFQgDgFgDgDQgDgEgGgCQgFgDgFAAQgHAAgEACgAFOAnIAAhNIA6AAIAAAMIgtAAIAAAVIAoAAIAAALIgoAAIAAAVIAtAAIAAAMgAEuAnIgUgbIgRAAIAAAbIgOAAIAAhNIAjAAQAGAAAHACQAGACAEAEIAEAHQACAFABAFQgBAEgCAEQgBAEgCACQgCADgEACIgIAEIAWAdgAEJAAIAUAAIAHAAIAFgDIAEgEIAAgGIAAgFIgEgEIgFgDIgHgBIgUAAgAB2AnIAAg3IgYAkIgBAAIgZgkIAAA3IgNAAIAAhNIAPAAIAYAlIAYglIAOAAIAABNgAgNAnIgsg3IAAA3IgNAAIAAhNIANAAIAqA1IAAg1IANAAIAABNgAhmAnIgUgbIgRAAIAAAbIgOAAIAAhNIAjAAQAFAAAJACQAFACAEAEIAFAHQACAFAAAFQAAAEgCAEIgEAGQgCADgEACIgIAEIAWAdgAiLAAIAUAAIAHAAIAGgDIADgEIAAgGIAAgFIgDgEIgGgDIgHgBIgUAAgAi3AnIgIgTIglAAIgIATIgOAAIAihOIAOAAIAiBOgAjEAIIgNgeIgOAeIAbAAgAlAAnIAAhNIA7AAIAAAMIgtAAIAAAVIAoAAIAAALIgoAAIAAAVIAtAAIAAAMgAmHAnIAAhNIANAAIAABBIAqAAIAAAMg");
	this.shape.setTransform(0,-0.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BUTTON
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2383A8").s().p("AnvCDQg3AAgngmQgmgnAAg2QAAg1AmgnQAngmA3AAIPgAAQA2AAAmAmQAnAnAAA1QAAA2gnAnQgmAmg2AAg");

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-62.8,-13.1,125.6,26.2), null);


(lib.bigBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,150,1,1.2);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mainimg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_334 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(334).call(this.frame_334).wait(1));

	// Technology-2
	this.instance = new lib.flightsurgeon();
	this.instance.parent = this;
	this.instance.setTransform(35,0,0.318,0.318);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:74},334,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(35,0,190.7,267);


// stage content:
(lib.MedPlus_Banner_flightsurgeon_160x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		// Enable mouse interaction with the stage 
		stage.enableMouseOver();
		
		// Define variables used in the 
		var root = this;
		var bigBtn = root.bigBtn;
		var cta = root.cta;
		var legalBtn = root.legalBtn;
		var legalPop = root.legalPop;
		
		// Add event listeners
		bigBtn.addEventListener("click", clickTag);
		bigBtn.addEventListener("mouseover", rollOver);
		bigBtn.addEventListener("mouseout", rollOut);
		/*
		legalBtn.addEventListener("click", legalUp);
		legalPop.addEventListener("click", legalDown);
		*/
		// Define functions to use throughout 
		function rollOver(){
			TweenMax.to(cta, .25, {scaleX:1.1, scaleY:1.1}); 
			console.log("over");
		};
		
		function rollOut(){
			TweenMax.to(cta, .25, {scaleX:1, scaleY:1});
			console.log("out");
		};
		
		function clickTag() {
			window.open(window.clickTag);
		}
		/*
		function legalUp(){
			TweenMax.to(legalPop, .5, {y:0, ease: Power1.easeOut}); 
		};
		
		function legalDown(){
			TweenMax.to(legalPop, .5, {y:250, ease: Power1.easeOut}); 
		};
		*/
	}
	this.frame_223 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(222).call(this.frame_223).wait(1));

	// bigBtn
	this.bigBtn = new lib.bigBtn();
	this.bigBtn.parent = this;
	this.bigBtn.setTransform(0,0,0.533,2);
	new cjs.ButtonHelper(this.bigBtn, 0, 1, 2, false, new lib.bigBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bigBtn).wait(224));

	// cta
	this.cta = new lib.cta();
	this.cta.parent = this;
	this.cta.setTransform(81.3,627.5);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(213).to({scaleX:0.04,scaleY:0.04,y:530},0).to({scaleX:1,scaleY:1,y:527.5},10,cjs.Ease.backOut).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(80,573.5,1.116,1.116,0,0,0,65.2,6.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(224));

	// txt-line-2a
	this.instance_1 = new lib.txtline2a();
	this.instance_1.parent = this;
	this.instance_1.setTransform(111.7,427.8,1,1,0,0,0,68.5,8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2b
	this.instance_2 = new lib.txtline2b();
	this.instance_2.parent = this;
	this.instance_2.setTransform(107.3,441.8,1,1,0,0,0,64.5,8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2c
	this.instance_3 = new lib.txtline2c();
	this.instance_3.parent = this;
	this.instance_3.setTransform(106.1,457.9,1,1,0,0,0,57.4,8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2d
	this.instance_4 = new lib.txtline2d();
	this.instance_4.parent = this;
	this.instance_4.setTransform(86.5,473.8,1,1,0,0,0,47.6,8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2e
	this.instance_5 = new lib.txtline2e();
	this.instance_5.parent = this;
	this.instance_5.setTransform(81.6,489.8,1,1,0,0,0,14,1083.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-1a
	this.instance_6 = new lib.txtline1a();
	this.instance_6.parent = this;
	this.instance_6.setTransform(70.7,426.3,1,1,0,0,0,60,8);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1b
	this.instance_7 = new lib.txtline1b();
	this.instance_7.parent = this;
	this.instance_7.setTransform(72.8,440.3,1,1,0,0,0,51,8);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1c
	this.instance_8 = new lib.txtline1c();
	this.instance_8.parent = this;
	this.instance_8.setTransform(74.2,454.3,1,1,0,0,0,54.9,8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1d
	this.instance_9 = new lib.txtline1d();
	this.instance_9.parent = this;
	this.instance_9.setTransform(78.3,473.1,1,1,0,0,0,58.1,8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1e
	this.instance_10 = new lib.txtline1e();
	this.instance_10.parent = this;
	this.instance_10.setTransform(64.9,492.1,1,1,0,0,0,32.5,8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// cross-cover
	this.instance_11 = new lib.crosscover();
	this.instance_11.parent = this;
	this.instance_11.setTransform(61.9,218.9,0.934,0.934,0,0,0,167.3,167.5);
	this.instance_11.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({alpha:1},5).wait(219));

	// cross-mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_5 = new cjs.Graphics().p("AsfbNMAAAg2ZISiAAIAASHIGdAAIAASqImdAAIAARog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(5).to({graphics:mask_graphics_5,x:80,y:219.1}).wait(219));

	// main-img
	this.instance_12 = new lib.mainimg();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-153,25,1.392,1.392);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(5).to({_off:false},0).wait(219));

	// red-bg
	this.instance_13 = new lib.redbg();
	this.instance_13.parent = this;
	this.instance_13.setTransform(0,0,0.533,2.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(224));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,300,350,640.6);
// library properties:
lib.properties = {
	id: '921C301E2A774CFD85816EFEBF3EA78D',
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Flight_Surgeon.jpg?1506104694506", id:"Flight_Surgeon"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['921C301E2A774CFD85816EFEBF3EA78D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;