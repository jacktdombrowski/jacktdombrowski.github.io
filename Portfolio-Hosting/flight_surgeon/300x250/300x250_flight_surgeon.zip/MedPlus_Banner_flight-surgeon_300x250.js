(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Flight_Surgeon = function() {
	this.initialize(img.Flight_Surgeon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,840);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtline2c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAKIAAgSIATAAIAAASg");
	this.shape.setTransform(107.4,10.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJAqIAAghIgfgyIAVAAIATAiIAVgiIAUAAIggAyIAAAhg");
	this.shape_1.setTransform(103,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_2.setTransform(94.6,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZAqIgIgTIgiAAIgIATIgTAAIAkhTIAQAAIAkBTgAALAHIgLgaIgKAaIAVAAg");
	this.shape_3.setTransform(85.3,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIAqIAAhCIgaAAIAAgRIBFAAIAAARIgaAAIAABCg");
	this.shape_4.setTransform(77.2,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_5.setTransform(71.3,7.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdAqIAAhTIASAAIAABCIApAAIAAARg");
	this.shape_6.setTransform(65.9,7.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_7.setTransform(59.9,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYAqIAAg2IgYAjIAAAAIgXgjIAAA2IgSAAIAAhTIAUAAIAVAjIAWgjIAUAAIAABTg");
	this.shape_8.setTransform(52.7,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_9.setTransform(40.1,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AARAqIAAghIghAAIAAAhIgSAAIAAhTIASAAIAAAiIAhAAIAAgiIATAAIAABTg");
	this.shape_10.setTransform(31.4,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgIAqIAAhCIgaAAIAAgRIBFAAIAAARIgaAAIAABCg");
	this.shape_11.setTransform(22.9,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape_12.setTransform(10.7,7.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_13.setTransform(4,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2c, new cjs.Rectangle(0,0,111.3,16), null);


(lib.txtline2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAqIgKgCIgIgEIgIgGIAKgNQAHAFAFACIAHACIAGABQAFAAADgCQAEgCAAgEIAAAAQAAgEgEgCQgDgDgJgCIgMgEIgJgEQgDgCgCgEQgCgFAAgFIAAgBQAAgFACgFQACgFAEgDQAEgEAGgCQAFgBAGAAIAIAAIAIACIAIAEIAHAEIgKAPQgGgFgFgCQgGgCgEAAQgFAAgDACQgDACAAAEQAAAEAEACQADACAKADIAMADQAFADADACQAEACABAFQACAEAAAFQAAAHgCAFQgCAEgFAEQgEADgFABQgGACgHAAIgIgBg");
	this.shape.setTransform(119.8,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_1.setTransform(111.9,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_2.setTransform(103.4,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_3.setTransform(95.3,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_4.setTransform(87,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAZAqIgIgTIgiAAIgIATIgTAAIAkhTIAQAAIAkBTgAALAHIgLgaIgKAaIAVAAg");
	this.shape_5.setTransform(77.6,7.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAqIgIgCIgHgEIgHgFIgFgHIgEgHIgCgIIgBgJIABgHIACgJIAEgHIAFgHIAHgFIAHgEIAJgDIAIAAIALAAIAIADQAGADAIAGIgMAOQgFgEgFgDQgFgDgGABQgFAAgEABQgEACgEAFIgFAIQgCAFAAAEQAAAGACAEQACAFADAEQADADAFACQAEADAFAAQAFAAAHgEQAEgCAGgEIAMAMIgHAGIgIAEIgJADIgLACIgIgCg");
	this.shape_6.setTransform(68.4,7.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgdAqIAAhTIASAAIAABCIApAAIAAARg");
	this.shape_7.setTransform(56.7,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZAqIgIgTIgiAAIgIATIgTAAIAkhTIAQAAIAkBTgAALAHIgLgaIgKAaIAVAAg");
	this.shape_8.setTransform(47.9,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAqIgIgCIgHgEIgHgFIgFgHIgEgHIgCgIIgBgJIABgHIACgJIAEgHIAFgHIAHgFIAHgEIAJgDIAIAAIALAAIAIADQAGADAIAGIgMAOQgFgEgFgDQgFgDgGABQgFAAgEABQgEACgEAFIgFAIQgCAFAAAEQAAAGACAEQACAFADAEQADADAFACQAEADAFAAQAFAAAHgEQAEgCAGgEIAMAMIgHAGIgIAEIgJADIgLACIgIgCg");
	this.shape_9.setTransform(38.7,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_10.setTransform(32.1,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgmAqIAAhTIAhAAIAJABIAIACIAIAEIAGAFIAGAGIADAIQACADABAEIABAIIgBAJIgDAIIgDAGIgGAHIgGAFIgIAEIgIACIgJABgAgTAaIAOAAQAFgBAEgCQAFgCADgCQAEgEACgEQABgFAAgGQAAgFgBgEQgCgFgEgDQgDgEgFgCQgEgBgFAAIgOAAg");
	this.shape_11.setTransform(25.5,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_12.setTransform(16.7,7.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAXAqIAAg2IgXAjIAAAAIgXgjIAAA2IgSAAIAAhTIAUAAIAVAjIAWgjIAUAAIAABTg");
	this.shape_13.setTransform(7.2,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2b, new cjs.Rectangle(0,0,126,16), null);


(lib.txtline2a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAqQgEAAgEgCIgIgDIgGgGIgFgGIgEgHIgDgJIAAgJIAAgHIADgJIAEgHIAGgHIAGgFIAHgEIAIgDIAJAAIAKAAIAJACQAFACAJAHIgLAOQgGgEgEgCQgGgDgHABQgDAAgFABQgFACgDAFIgFAIQgCAFAAAEQAAAGACAFQACAEADAEQAEAEAEABQAFADAEAAIAKgBIAIgFIAAgLIgTAAIAAgQIAlAAIAAAkQgKAHgFACIgKADIgLACIgJgCg");
	this.shape.setTransform(126.8,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape_1.setTransform(117.4,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_2.setTransform(110.7,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIAqIAAhCIgaAAIAAgRIBFAAIAAARIgaAAIAABCg");
	this.shape_3.setTransform(104.8,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_4.setTransform(98.9,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgEAqIgIgCIgHgEIgHgFIgFgHIgEgHIgCgIIgBgJIABgHIACgJIAEgHIAFgHIAHgFIAHgEIAJgDIAIAAIALAAIAIADQAGADAIAGIgMAOQgFgEgFgDQgFgDgGABQgFAAgEABQgEACgEAFIgFAIQgCAFAAAEQAAAGACAEQACAFADAEQADADAFACQAEADAFAAQAFAAAHgEQAEgCAGgEIAMAMIgHAGIgIAEIgJADIgLACIgIgCg");
	this.shape_5.setTransform(92.6,7.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATAqIgTgdIgSAdIgVAAIAdgqIgcgpIAWAAIAQAbIASgbIAVAAIgcApIAdAqg");
	this.shape_6.setTransform(83.7,7.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_7.setTransform(75.5,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_8.setTransform(63.7,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_9.setTransform(55.3,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHAqIgihTIAUAAIAVA6IAWg6IAUAAIgiBTg");
	this.shape_10.setTransform(46.6,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJAqIgIgCIgIgEIgGgFIgFgHIgFgHIgCgIIgBgJIABgHIACgJIAFgHIAFgHIAGgFIAIgEIAJgDIAIAAIAJAAIAJADIAIAEIAGAFIAFAGIAFAIIACAIIAAAIIAAAJIgCAIIgFAHIgFAGIgGAGIgIAEIgJACIgJACIgJgCgAgJgYQgFACgEAFIgFAIQgCAFAAAEQAAAGACAEQADAFADAEQAEADAEACQAFADAEAAQAGAAAEgDQAFgCADgDIAGgIQACgFAAgGQAAgFgCgEQgCgFgEgDQgEgFgEgCQgFgBgFAAQgFAAgEABg");
	this.shape_11.setTransform(37,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgEAqIgIgCIgHgEIgHgFIgFgHIgEgHIgCgIIgBgJIABgHIACgJIAEgHIAFgHIAHgFIAHgEIAJgDIAIAAIALAAIAIADQAGADAIAGIgMAOQgFgEgFgDQgFgDgGABQgFAAgEABQgEACgEAFIgFAIQgCAFAAAEQAAAGACAEQACAFADAEQADADAFACQAEADAFAAQAFAAAHgEQAEgCAGgEIAMAMIgHAGIgIAEIgJADIgLACIgIgCg");
	this.shape_12.setTransform(27.5,7.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAqIgKgCIgIgEIgIgGIAKgNQAHAFAFACIAHACIAGABQAFAAADgCQAEgCAAgEIAAAAQAAgEgEgCQgDgDgJgCIgMgEIgJgEQgDgCgCgEQgCgFAAgFIAAgBQAAgFACgFQACgFAEgDQAEgEAGgCQAFgBAGAAIAIAAIAIACIAIAEIAHAEIgKAPQgGgFgFgCQgGgCgEAAQgFAAgDACQgDACAAAEQAAAEAEACQADACAKADIAMADQAFADADACQAEACABAFQACAEAAAFQAAAHgCAFQgCAEgFAEQgEADgFABQgGACgHAAIgIgBg");
	this.shape_13.setTransform(19.1,7.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_14.setTransform(13.4,7.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgmAqIAAhTIAhAAIAJABIAIACIAIAEIAGAFIAGAGIADAIQACADABAEIABAIIgBAJIgDAIIgDAGIgGAHIgGAFIgIAEIgIACIgJABgAgTAaIAOAAQAFgBAEgCQAFgCADgCQAEgEACgEQABgFAAgGQAAgFgBgEQgCgFgEgDQgDgEgFgCQgEgBgFAAIgOAAg");
	this.shape_15.setTransform(6.9,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2a, new cjs.Rectangle(0,0,133.7,16), null);


(lib.txtline1c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLArIAAgTIASAAIAAATgAgHAOIgDgSIABgBIAJgBIAGgDIAEgCIABgFIAAgBQAAgDgDgCQgDgDgFAAQgEAAgFADQgEACgEADIgLgLIAFgGIAHgEQAEgCAEAAIAIgCQAHAAAFACQAFABAEAEQAEADACAFQACAEAAAGQAAAGgCAEIgFAHIgHAEIgKADIgBAHg");
	this.shape.setTransform(131.3,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape_1.setTransform(123.3,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAqIgIgCIgHgEIgHgFIgGgHIgDgHIgDgIIAAgJIAAgHIADgJIADgHIAGgHIAHgFIAHgEIAJgDIAIAAIAKAAIAIADIAHAEIAHAFIAGAGIADAIIADAIIAAAIIAAAJIgDAIIgDAHIgGAGIgHAGIgHAEIgJACIgJACIgJgCgAgKgYQgEACgEAFIgEAIQgCAFAAAEQAAAGACAEQACAFADAEQAEADAEACQAFADAEAAQAFAAAGgDQAEgCAEgDIAEgIQACgFAAgGQAAgFgCgEQgCgFgDgDQgEgFgEgCQgFgBgFAAQgEAAgGABg");
	this.shape_2.setTransform(113.4,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA+AAIAAARIgsAAIAAARIAnAAIAAAPIgnAAIAAASIAtAAIAAAQg");
	this.shape_3.setTransform(104.4,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgFAqQgEAAgEgCIgHgDIgHgGIgFgGIgEgHIgCgJIgBgJIABgHIACgJIAEgHIAGgHIAGgFIAHgEIAIgDIAJAAIAKAAIAJACQAFACAJAHIgLAOQgGgEgEgCQgGgDgHABQgEAAgEABQgFACgDAFIgFAIQgCAFAAAEQAAAGACAFQACAEADAEQAEAEAEABQAFADAEAAIAKgBIAIgFIAAgLIgTAAIAAgQIAlAAIAAAkQgKAHgFACIgKADIgLACIgJgCg");
	this.shape_4.setTransform(95.4,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_5.setTransform(86.6,7.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPAoIgGgDIgFgEIgEgFIgDgGIgCgIIAAgJIAAgvIASAAIAAAvQgBAFACAEQABAEACACIAGAEQADACAEAAQAEAAAEgCQADgBACgDQADgCABgEQABgEAAgFIAAgvIATAAIAAAvIgBAJIgCAHIgEAHIgDAFIgGAEIgGADQgKADgFAAIgPgDg");
	this.shape_6.setTransform(77.4,7.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgGAqIgKgCIgIgEIgIgGIAKgNQAHAFAFACIAHACIAGABQAFAAADgCQAEgCAAgEIAAAAQAAgEgEgCQgDgDgJgCIgMgEIgJgEQgDgCgCgEQgCgFAAgFIAAgBQAAgFACgFQACgFAEgDQAEgEAGgCQAFgBAGAAIAIAAIAIACIAIAEIAHAEIgKAPQgGgFgFgCQgGgCgEAAQgFAAgDACQgDACAAAEQAAAEAEACQADACAKADIAMADQAFADADACQAEACABAFQACAEAAAFQAAAHgCAFQgCAEgFAEQgEADgFABQgGACgHAAIgIgBg");
	this.shape_7.setTransform(68.8,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIAqIAAhCIgaAAIAAgRIBFAAIAAARIgaAAIAABCg");
	this.shape_8.setTransform(57.4,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AARAqIAAghIghAAIAAAhIgTAAIAAhTIATAAIAAAiIAhAAIAAgiIASAAIAABTg");
	this.shape_9.setTransform(48.9,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAqQgEAAgEgCIgIgDIgGgGIgFgGIgEgHIgDgJIAAgJIAAgHIADgJIAEgHIAGgHIAGgFIAHgEIAIgDIAJAAIAKAAIAJACQAFACAJAHIgLAOQgGgEgEgCQgGgDgHABQgDAAgFABQgFACgDAFIgFAIQgCAFAAAEQAAAGACAFQACAEADAEQAEAEAEABQAFADAEAAIAKgBIAIgFIAAgLIgTAAIAAgQIAlAAIAAAkQgKAHgFACIgKADIgLACIgJgCg");
	this.shape_10.setTransform(39.5,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgIAqIAAhTIARAAIAABTg");
	this.shape_11.setTransform(32.7,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAqIAAhTIASAAIAABCIApAAIAAARg");
	this.shape_12.setTransform(27.2,7.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgtAAIAAASIAoAAIAAAQIgoAAIAAAgg");
	this.shape_13.setTransform(19.5,7.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAZAqIgIgTIgiAAIgIATIgSAAIAkhTIAPAAIAkBTgAALAHIgLgaIgLAaIAWAAg");
	this.shape_14.setTransform(6.8,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1c, new cjs.Rectangle(0,0,137,16), null);


(lib.txtline1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape.setTransform(121.2,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgjAqIAAhTIAmAAQAIAAAFACQAGACADAEQADADACADQABADAAAEIAAABIgBAGIgCAGQgDADgFADIAHADIAFADIADAGIABAIIAAAAQAAAGgDAEQgCAFgEADQgEACgGABQgGACgHAAgAgRAaIAVAAQAHAAADgDQADgCAAgEQAAgFgDgCIgEgCIgGAAIgVAAgAgRgHIARAAQAGAAADgCQAEgCAAgFQAAgFgDgCQgEgCgFAAIgSAAg");
	this.shape_1.setTransform(112.9,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape_2.setTransform(100,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZAqIgIgTIgiAAIgIATIgTAAIAkhTIAQAAIAkBTgAALAHIgLgaIgKAaIAVAAg");
	this.shape_3.setTransform(90.6,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAqIgIgCIgHgEIgHgFIgFgHIgEgHIgCgIIgBgJIABgHIACgJIAEgHIAFgHIAHgFIAHgEIAJgDIAIAAIALAAIAIADQAGADAIAGIgMAOQgFgEgFgDQgFgDgGABQgFAAgEABQgEACgEAFIgFAIQgCAFAAAEQAAAGACAEQACAFADAEQADADAFACQAEADAFAAQAFAAAHgEQAEgCAGgEIAMAMIgHAGIgIAEIgJADIgLACIgIgCg");
	this.shape_4.setTransform(81.5,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPAoIgGgDIgFgEIgEgFIgDgGIgCgIIgBgJIAAgvIASAAIAAAvQABAFABAEQABAEADACIAFAEQADACAEAAQAEAAAEgCQADgBACgDQACgCACgEQABgEAAgFIAAgvIASAAIAAAvIAAAJIgCAHIgEAHIgEAFIgFAEIgGADQgKADgFAAIgPgDg");
	this.shape_5.setTransform(68.9,7.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgIAqIgJgCIgHgEIgHgFIgFgHIgFgHIgCgIIAAgJIAAgHIACgJIAFgHIAFgHIAHgFIAHgEIAJgDIAIAAIAKAAIAIADIAIAEIAGAFIAGAGIADAIIADAIIABAIIgBAJIgDAIIgDAHIgGAGIgGAGIgIAEIgJACIgJACIgIgCgAgJgYQgFACgDAFIgGAIQgCAFABAEQgBAGACAEQACAFAEAEQAEADAEACQAFADAEAAQAGAAAEgDQAFgCAEgDIAEgIQADgFAAgGQAAgFgDgEQgBgFgEgDQgDgFgFgCQgEgBgGAAQgEAAgFABg");
	this.shape_6.setTransform(59.3,7.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIAqIAAghIghgyIAWAAIATAiIAUgiIAWAAIghAyIAAAhg");
	this.shape_7.setTransform(49.9,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape_8.setTransform(37.3,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA+AAIAAARIgsAAIAAARIAnAAIAAAPIgnAAIAAASIAtAAIAAAQg");
	this.shape_9.setTransform(28.8,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AARAqIAAghIghAAIAAAhIgSAAIAAhTIASAAIAAAiIAhAAIAAgiIATAAIAABTg");
	this.shape_10.setTransform(20,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AATAqIgTg2IgSA2IgQAAIgdhTIAUAAIASA4IASg5IAPAAIATA5IARg4IAUAAIgdBTg");
	this.shape_11.setTransform(8.7,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1b, new cjs.Rectangle(0,0,127.2,16), null);


(lib.txtline1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAWAqIgog1IAAA1IgSAAIAAhTIARAAIAmAzIAAgzIASAAIAABTg");
	this.shape.setTransform(129.2,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJAqIgIgCIgHgEIgHgFIgGgHIgDgHIgDgIIAAgJIAAgHIADgJIADgHIAGgHIAHgFIAHgEIAJgDIAIAAIAKAAIAIADIAHAEIAHAFIAGAGIADAIIADAIIAAAIIAAAJIgDAIIgDAHIgGAGIgHAGIgHAEIgJACIgJACIgJgCgAgKgYQgEACgEAFIgEAIQgCAFAAAEQAAAGACAEQACAFADAEQAEADAEACQAFADAEAAQAFAAAGgDQAEgCAEgDIAEgIQACgFAAgGQAAgFgCgEQgCgFgDgDQgEgFgEgCQgFgBgFAAQgEAAgGABg");
	this.shape_1.setTransform(119.3,7.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA/AAIAAARIgsAAIAAARIAmAAIAAAPIgmAAIAAASIAsAAIAAAQg");
	this.shape_2.setTransform(110.3,7.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFAqQgEAAgEgCIgHgDIgHgGIgFgGIgEgHIgCgJIgBgJIABgHIACgJIAEgHIAGgHIAGgFIAHgEIAIgDIAJAAIAKAAIAJACQAFACAJAHIgLAOQgGgEgEgCQgGgDgHABQgEAAgEABQgFACgDAFIgFAIQgCAFAAAEQAAAGACAFQACAEADAEQAEAEAEABQAFADAEAAIAKgBIAIgFIAAgLIgTAAIAAgQIAlAAIAAAkQgKAHgFACIgKADIgLACIgJgCg");
	this.shape_3.setTransform(101.2,7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAPAqIgRgbIgPAAIAAAbIgSAAIAAhTIAlAAQAGAAAIACQAHADAEADQADAEACAFQACAFAAAGIgBAJQgCAEgCADQgCADgEACIgHAEIAUAegAgRAAIASAAIAGgBIAEgDIADgDIABgFIAAgBIgBgEIgDgFIgEgCIgGAAIgSAAg");
	this.shape_4.setTransform(92.4,7.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPAoIgGgDIgFgEIgEgFIgDgGIgCgIIAAgJIAAgvIASAAIAAAvQgBAFACAEQABAEACACIAGAEQADACAEAAQAEAAAEgCQADgBACgDQADgCABgEQABgEAAgFIAAgvIASAAIAAAvIAAAJIgCAHIgEAHIgDAFIgGAEIgGADQgKADgFAAIgPgDg");
	this.shape_5.setTransform(83.2,7.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAqIgKgCIgIgEIgIgGIAKgNQAHAFAFACIAHACIAGABQAFAAADgCQAEgCAAgEIAAAAQAAgEgEgCQgDgDgJgCIgMgEIgJgEQgDgCgCgEQgCgFAAgFIAAgBQAAgFACgFQACgFAEgDQAEgEAGgCQAFgBAGAAIAIAAIAIACIAIAEIAHAEIgKAPQgGgFgFgCQgGgCgEAAQgFAAgDACQgDACAAAEQAAAEAEACQADACAKADIAMADQAFADADACQAEACABAFQACAEAAAFQAAAHgCAFQgCAEgFAEQgEADgFABQgGACgHAAIgIgBg");
	this.shape_6.setTransform(74.7,7.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZAqIgHgTIgjAAIgIATIgSAAIAkhTIAQAAIAkBTgAALAHIgLgaIgKAaIAVAAg");
	this.shape_7.setTransform(62.4,7.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAqIAAhTIA+AAIAAARIgsAAIAAARIAnAAIAAAPIgnAAIAAASIAtAAIAAAQg");
	this.shape_8.setTransform(50.1,7.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjAqIAAhTIAmAAQAIAAAFACQAGACADAEQADADACADQABADAAAEIAAABIgBAGIgCAGQgDADgFADIAHADIAFADIADAGIABAIIAAAAQAAAGgDAEQgCAFgEADQgEACgGABQgGACgHAAgAgRAaIAVAAQAHAAADgDQADgCAAgEQAAgFgDgCIgEgCIgGAAIgVAAgAgRgHIARAAQAGAAADgCQAEgCAAgFQAAgFgDgCQgEgCgFAAIgSAAg");
	this.shape_9.setTransform(41.7,7.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJAqIAAghIgfgyIAVAAIATAiIAVgiIAVAAIghAyIAAAhg");
	this.shape_10.setTransform(29.1,7.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AARAqIAAghIghAAIAAAhIgSAAIAAhTIASAAIAAAiIAhAAIAAgiIATAAIAABTg");
	this.shape_11.setTransform(20.1,7.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AATAqIgTg2IgSA2IgQAAIgdhTIAUAAIASA4IASg5IAPAAIATA5IARg4IAUAAIgdBTg");
	this.shape_12.setTransform(8.7,7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1a, new cjs.Rectangle(0,0,136.2,16), null);


(lib.redbg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84639").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.redbg, new cjs.Rectangle(0,0,300,250), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAfIAAgZIgYglIAQAAIAOAaIAPgaIAQAAIgYAlIAAAZg");
	this.shape.setTransform(124.6,6.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AALAfIgMgUIgLAAIAAAUIgOAAIAAg+IAcAAIAKACQAFACADADQADADABADIABAJIgBAGIgCAFIgFAEIgFADIAPAWgAgMAAIANAAIAEAAIAEgDIACgCIAAgEIAAgEIgDgCIgDgCIgFgBIgMAAg");
	this.shape_1.setTransform(118.4,6.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAgIgGgOIgaAAIgFAOIgOAAIAag/IAMAAIAbA/gAAIAFIgIgTIgHATIAPAAg");
	this.shape_2.setTransform(111.4,6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_3.setTransform(104.9,6.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_4.setTransform(100.5,6.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAg+IAOAAIAAAyIAfAAIAAAMg");
	this.shape_5.setTransform(96.5,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_6.setTransform(92,6.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIAQgbIAQAAIAAA+g");
	this.shape_7.setTransform(86.6,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAcAAIAAALIgcAAIAAANIAhAAIAAAMg");
	this.shape_8.setTransform(77.1,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AANAfIAAgZIgZAAIAAAZIgOAAIAAg+IAOAAIAAAaIAZAAIAAgaIAOAAIAAA+g");
	this.shape_9.setTransform(70.6,6.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_10.setTransform(64.3,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAuAAIAAANIggAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_11.setTransform(45.7,6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAfIgdgmIAAAmIgOAAIAAg+IANAAIAdAnIAAgnIANAAIAAA+g");
	this.shape_12.setTransform(39,6.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_13.setTransform(33.9,6.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgCAgIgHgCIgGgDIgEgEIgEgEIgDgGIgBgGIgBgHIABgFIABgHIADgFIAEgFIAEgEIAHgDIAGgCIAFgBIAIABIAHACIAKAHIgJAKQgDgDgEgCQgEgCgFAAQgDAAgDACQgDABgCADIgFAGIgBAHQAAAEABAEIAFAGIAFAEQADACADAAQAEAAAFgCIAIgGIAJAJIgFAFIgGADIgHADIgIAAIgFAAg");
	this.shape_14.setTransform(29.2,6.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_15.setTransform(24.3,6.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAfIAAg+IAYAAIAHABIAGACIAGADIAFADIADAFIAEAFIACAHIAAAFIAAAGIgCAGIgEAGIgDAEIgFAEIgGADIgGACIgHAAgAgOATIAKAAQAEAAADgBQAEgBADgDIADgGQACgDgBgFQABgDgCgDQgBgEgCgDIgHgDQgDgCgEAAIgKAAg");
	this.shape_16.setTransform(19.5,6.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_17.setTransform(13,6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIARgbIAPAAIAAA+g");
	this.shape_18.setTransform(5.9,6.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAgQgNgNAAgTQAAgSANgNQANgNASAAQATAAANANQANANAAASQAAATgNANQgNANgTAAQgSAAgNgNgAgaAKIATAAIAAATIAQAAIAAgTIATAAIAAgSIgTAAIAAgTIgQAAIAAATIgTAAg");
	this.shape_19.setTransform(55.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,130,13), null);


(lib.flightsurgeon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Flight_Surgeon();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.flightsurgeon, new cjs.Rectangle(0,0,600,840), null);


(lib.crosscover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAgMAOIAaAAIAAgbIgaAAg");
	this.shape.setTransform(167.4,167.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAiuCwIFeAAIAAlfIleAAg");
	this.shape_1.setTransform(167.4,167.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAlIFJIKRAAIAAqRIqRAAg");
	this.shape_2.setTransform(167.4,167.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAnZHaQOpACALgBQABgLgBuqIu0AAg");
	this.shape_3.setTransform(167.4,167.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgApiJjQS8ACAKgBQABgKgBy9IzGAAg");
	this.shape_4.setTransform(167.4,167.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgArjLkQW+ACAJgCQACgJgC2+I3HAAg");
	this.shape_5.setTransform(167.4,167.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAtbNcQavACAJgBQABgJgB6wI64AAg");
	this.shape_6.setTransform(167.4,167.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAvLPMQeQADAIgCQACgIgC+RI+YAAg");
	this.shape_7.setTransform(167.4,167.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAwzQ0UAhgAADAAHgADUAADgAHgADghgMghnAAAg");
	this.shape_8.setTransform(167.4,167.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAyTSUUAkgAACAAHgACUAACgAHgACgkgMgknAAAg");
	this.shape_9.setTransform(167.4,167.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAzqTrUAnPAADAAGgADUAADgAGgADgnPMgnVAAAg");
	this.shape_10.setTransform(167.4,167.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA05U6UAptAADAAGgADUAADgAGgADgptMgpzAAAg");
	this.shape_11.setTransform(167.4,167.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA1/WAUAr6AAEAAGgADUAADgAGgADgr7MgsAAAAg");
	this.shape_12.setTransform(167.4,167.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA2+W+UAt4AAEAAFgADUAADgAFgADgt4Mgt9AAAg");
	this.shape_13.setTransform(167.4,167.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA30X0UAvkAAEAAFgADUAADgAFgADgvkMgvpAAAg");
	this.shape_14.setTransform(167.4,167.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA4hYiUAw/AAEAAEgAEUAAEgAEgAEgw/MgxDAAAg");
	this.shape_15.setTransform(167.4,167.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA5HZHUAyLAAEAAEgADUAADgAEgADgyLMgyPAAAg");
	this.shape_16.setTransform(167.4,167.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA5kZkUAzFAAEAAEgADUAADgAEgADgzFMgzJAAAg");
	this.shape_17.setTransform(167.4,167.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA55Z5UAzvAAEAAEgADUAADgAEgADgzvMgzzAAAg");
	this.shape_18.setTransform(167.4,167.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA6FaGUA0IAAEAADgAEUAAEgADgAEg0IMg0LAAAg");
	this.shape_19.setTransform(167.4,167.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA6JaKUA0QAAEAADgAEUAAEgADgAEg0QMg0TAAAg");
	this.shape_20.setTransform(167.4,167.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},4).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-20,374.9,374.9);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// LEARN MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACKAeIgFgCIgGgCIgFgEIgDgFIgCgFIgCgGIgBgGIAAAAIABgFIACgGIACgFIAEgFIAEgDIAGgDIAFgCIAHgBIAHABIAGACIAFADIAEADIAFAFIACAFIABAGIABAFIgBAGIgBAGIgDAFIgEAFIgEADIgGADIgFACIgHABIgHgBgACJgTIgHAFQgCADgBAEIgCAHQAAAEACAEIADAHQAEADADABQAEACAEAAQAFAAAEgCQADgBADgDQACgDACgEIABgIIAAAAIgBgHQgCgEgCgDQgDgDgEgBQgDgCgFAAQgEAAgEABgAD9AeIAAg7IAsAAIAAAKIgiAAIAAAPIAeAAIAAAIIgeAAIAAAQIAiAAIAAAKgADkAeIgOgVIgOAAIAAAVIgKAAIAAg7IAbAAIAJACQAFABADADIADAGQACADAAAEQAAAEgCADIgCAEIgFAEIgFACIAQAXgADIAAIAQAAIAFAAIAEgCIACgDIABgEIgBgFIgCgDIgEgCIgFAAIgQAAgABaAeIAAgqIgTAbIAAAAIgTgbIAAAqIgLAAIAAg7IAMAAIASAcIASgcIALAAIAAA7gAgJAeIghgqIAAAqIgLAAIAAg7IAKAAIAfAoIAAgoIALAAIAAA7gAhNAeIgPgVIgNAAIAAAVIgKAAIAAg7IAaAAIAKACQAFABADADIADAGQABADAAAEQAAAEgBADIgCAEIgFAEIgGACIAQAXgAhpAAIAQAAIAEAAIAFgCIACgDIAAgEIAAgFIgCgDIgFgCIgEAAIgQAAgAiKAeIgGgPIgcAAIgGAPIgLAAIAag7IAKAAIAaA7gAiUAGIgKgXIgKAXIAUAAgAjyAeIAAg7IAtAAIAAAKIgjAAIAAAPIAeAAIAAAIIgeAAIAAAQIAjAAIAAAKgAkoAeIAAg7IAKAAIAAAxIAgAAIAAAKg");
	this.shape.setTransform(0,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BUTTON
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2383A8").s().p("Al3BjQgpAAgdgdQgdgdAAgpQAAgoAdgdQAdgdApAAILvAAQApAAAdAdQAdAdAAAoQAAApgdAdQgdAdgpAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-47.5,-9.9,95.1,19.9), null);


(lib.bigBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,150,1,1.2);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mainimg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_334 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(334).call(this.frame_334).wait(1));

	// Flight-Surgeon
	this.instance = new lib.flightsurgeon();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,0,0.483,0.483);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:0},334,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,0,290,406);


// stage content:
(lib.MedPlus_Banner_flightsurgeon_300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// Enable mouse interaction with the stage 
		stage.enableMouseOver();
		
		// Define variables used in the 
		var root = this;
		var bigBtn = root.bigBtn;
		var cta = root.cta;
		var legalBtn = root.legalBtn;
		var legalPop = root.legalPop;
		
		// Add event listeners
		bigBtn.addEventListener("click", clickTag);
		bigBtn.addEventListener("mouseover", rollOver);
		bigBtn.addEventListener("mouseout", rollOut);
		/*
		legalBtn.addEventListener("click", legalUp);
		legalPop.addEventListener("click", legalDown);
		*/
		// Define functions to use throughout 
		function rollOver(){
			TweenMax.to(cta, .25, {scaleX:1.1, scaleY:1.1}); 
		};
		
		function rollOut(){
			TweenMax.to(cta, .25, {scaleX:1, scaleY:1});
		};
		
		function clickTag() {
			window.open(window.clickTag);
		}
		/*
		function legalUp(){
			TweenMax.to(legalPop, .5, {y:0, ease: Power1.easeOut}); 
		};
		
		function legalDown(){
			TweenMax.to(legalPop, .5, {y:250, ease: Power1.easeOut}); 
		};
		*/
	}
	this.frame_223 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(223).call(this.frame_223).wait(1));

	// bigBtn
	this.bigBtn = new lib.bigBtn();
	this.bigBtn.parent = this;
	this.bigBtn.setTransform(150,104.2,1,0.833,0,0,0,150,125);
	new cjs.ButtonHelper(this.bigBtn, 0, 1, 2, false, new lib.bigBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bigBtn).wait(224));

	// cta
	this.cta = new lib.cta();
	this.cta.parent = this;
	this.cta.setTransform(71.8,184.9,0.05,0.05);
	this.cta._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(213).to({_off:false},0).to({scaleX:1,scaleY:1,x:69.5,y:185},10,cjs.Ease.backOut).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(85,228.1,1,1,0,0,0,65,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(224));

	// txt-line-2a
	this.instance_1 = new lib.txtline2a();
	this.instance_1.parent = this;
	this.instance_1.setTransform(88.5,130.8,1,1,0,0,0,68.5,8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2b
	this.instance_2 = new lib.txtline2b();
	this.instance_2.parent = this;
	this.instance_2.setTransform(84.5,144.8,1,1,0,0,0,64.5,8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2c
	this.instance_3 = new lib.txtline2c();
	this.instance_3.parent = this;
	this.instance_3.setTransform(77.4,158.8,1,1,0,0,0,57.4,8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(173).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-1a
	this.instance_4 = new lib.txtline1a();
	this.instance_4.parent = this;
	this.instance_4.setTransform(80,130.8,1,1,0,0,0,60,8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1b
	this.instance_5 = new lib.txtline1b();
	this.instance_5.parent = this;
	this.instance_5.setTransform(71,144.8,1,1,0,0,0,51,8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// txt-line-1c
	this.instance_6 = new lib.txtline1c();
	this.instance_6.parent = this;
	this.instance_6.setTransform(74.9,158.8,1,1,0,0,0,54.9,8);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(38).to({_off:false},0).to({alpha:1},8).wait(97).to({alpha:0},8).wait(73));

	// cross-cover
	this.instance_7 = new lib.crosscover();
	this.instance_7.parent = this;
	this.instance_7.setTransform(222.2,64.1,1,1,0,0,0,167.4,167.4);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({alpha:1},5,cjs.Ease.sineOut).wait(219));

	// cross-mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_5 = new cjs.Graphics().p("AnwaiIAAyxIyXAAIAAvhISXAAIAAyxIPiAAIAASxISWAAIAAPhIyWAAIAASxg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(5).to({graphics:mask_graphics_5,x:221.9,y:61.3}).wait(219));

	// main-img
	this.instance_8 = new lib.mainimg();
	this.instance_8.parent = this;
	this.instance_8.setTransform(54.7,-133.9,1.092,1.092);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(5).to({_off:false},0).wait(219));

	// red-bg
	this.instance_9 = new lib.redbg();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(224));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,1.7,409.6,374.9);
// library properties:
lib.properties = {
	id: '921C301E2A774CFD85816EFEBF3EA78D',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Flight_Surgeon.jpg?1506104512069", id:"Flight_Surgeon"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['921C301E2A774CFD85816EFEBF3EA78D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;