(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"MedPlus_Banner_everywhere_300x600_atlas_", frames: [[0,0,600,400],[0,402,600,400]]}
];


// symbols:



(lib.Humanitarian1 = function() {
	this.spriteSheet = ss["MedPlus_Banner_everywhere_300x600_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Humanitarian2 = function() {
	this.spriteSheet = ss["MedPlus_Banner_everywhere_300x600_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtline2c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfIAfAAIAAAfg");
	this.shape.setTransform(174.5,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBGIAAg3Ig1hUIAkAAIAgA4IAig4IAjAAIg2BTIAAA4g");
	this.shape_1.setTransform(166.5,11);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPADQAKAFAHAGQAGAGADAIQADAIAAAKQAAAJgCAHQgCAHgEAEQgEAGgGADQgFAFgHACIAjAygAgdgBIAeAAQAGAAAEgCIAIgDIAFgHQABgEAAgEQAAgFgCgEQgCgDgCgDQgDgCgFgCIgKgBIgeAAg");
	this.shape_2.setTransform(153,11);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAqBHIgNggIg6AAIgNAgIgfAAIA8iNIAbAAIA8CNgAASAMIgSgtIgSAtIAkAAg");
	this.shape_3.setTransform(137.2,11);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgPBGIAAhvIgqAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_4.setTransform(124.4,11);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOBGIAAiLIAdAAIAACLg");
	this.shape_5.setTransform(114.4,11);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBGIAAiLIAeAAIAABvIBFAAIAAAcg");
	this.shape_6.setTransform(105.3,11);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgPBGIAAiLIAeAAIAACLg");
	this.shape_7.setTransform(95.2,11);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAnBGIAAhbIgnA7IAAAAIgng6IAABaIgeAAIAAiLIAhAAIAkA7IAkg7IAiAAIAACLg");
	this.shape_8.setTransform(83.1,11);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_9.setTransform(61.8,11);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAcBGIAAg4Ig4AAIAAA4IgeAAIAAiLIAeAAIAAA3IA4AAIAAg3IAfAAIAACLg");
	this.shape_10.setTransform(47.1,11);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBGIAAhvIgqAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_11.setTransform(32.9,11);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAkBGIhDhYIAABYIgeAAIAAiLIAcAAIBBBVIAAhVIAeAAIAACLg");
	this.shape_12.setTransform(12.3,11);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgPBGIAAiLIAfAAIAACLg");
	this.shape_13.setTransform(1,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2c, new cjs.Rectangle(-4.4,0,184.1,24), null);


(lib.txtline2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKBHIgQgFIgPgGIgNgKIASgWQAKAIAJAEIALAEIAKABQAKAAAFgDQAGgEAAgGIAAgBQAAgGgGgEQgFgDgQgEIgUgGQgIgEgGgEQgGgEgDgHQgDgHgBgKIAAgBQAAgJAEgIQAEgIAGgGQAHgFAJgDQAIgDALAAIAOABIANAEIANAFIAMAIIgQAXQgLgGgIgEQgJgEgIAAQgIAAgGAEQgEADAAAFIAAABQAAAGAGAEQAFADASAFQAMADAHADQAIAEAGAEQAGAFADAGQACAHAAAJIAAAAQAAALgDAIQgEAIgHAGQgGAFgKADQgJADgMAAQgHAAgHgBg");
	this.shape.setTransform(193.5,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPAEQAKAEAHAGQAGAGADAIQADAJAAAJQAAAJgCAHQgCAHgEAFQgEAEgGAFQgFAEgHACIAjAygAgdgBIAeAAQAGAAAEgBIAIgFIAFgFQABgFAAgEQAAgFgCgEQgCgDgCgDQgDgDgFgBIgLgBIgdAAg");
	this.shape_1.setTransform(180.4,14);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_2.setTransform(166.2,14);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_3.setTransform(152.7,14);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAZBGIgdgtIgZAAIAAAtIgeAAIAAiLIA/AAQAIAAAPAEQAKAEAHAGQAGAGADAIQADAJAAAJQAAAJgCAHQgCAHgEAFQgEAEgFAFQgGAEgHACIAiAygAgdgBIAeAAQAGAAAFgBIAGgFIAGgFQABgFAAgEQAAgFgCgEQgBgDgEgDQgDgDgEgBIgLgBIgdAAg");
	this.shape_4.setTransform(138.9,14);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAqBGIgNgfIg6AAIgNAfIgfAAIA8iLIAbAAIA8CLgAASAMIgSgsIgSAsIAkAAg");
	this.shape_5.setTransform(123.1,14);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHBHIgNgEIgNgHIgKgIIgJgLQgEgGgCgHIgEgNQgCgHAAgIIAAAAQAAgGACgIIAEgNQACgGAEgGIAJgLIAKgJQAGgEAHgCIAOgFQAGgBAIgBQAKABAIABQAIABAHAEQAJADAOAMIgUAXQgJgIgIgEQgJgEgKAAQgIAAgHAEQgHADgGAGQgFAGgDAHQgDAIAAAJIAAAAQAAAJADAIQACAIAGAGQAFAGAIAEQAHADAIAAQAIAAAMgFQAIgDAJgJIAUAUIgMALQgGAEgGADQgHAEgIACQgJABgKAAQgHABgHgCg");
	this.shape_6.setTransform(107.9,14);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxBGIAAiLIAeAAIAABvIBFAAIAAAcg");
	this.shape_7.setTransform(88.5,14);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAqBGIgNgfIg6AAIgNAfIgfAAIA8iLIAbAAIA8CLgAASAMIgSgsIgSAsIAkAAg");
	this.shape_8.setTransform(73.8,14);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgHBHIgNgEIgNgHIgKgIIgJgLQgEgGgCgHIgEgNQgCgHAAgIIAAAAQAAgGACgIIAEgNQACgGAEgGIAJgLIAKgJQAGgEAHgCIAOgFQAGgBAIgBQAKABAIABQAIABAHAEQAJADAOAMIgUAXQgJgIgIgEQgJgEgKAAQgIAAgHAEQgHADgGAGQgFAGgDAHQgDAIAAAJIAAAAQAAAJADAIQACAIAGAGQAFAGAIAEQAHADAIAAQAIAAAMgFQAIgDAJgJIAUAUIgMALQgGAEgGADQgHAEgIACQgJABgKAAQgHABgHgCg");
	this.shape_9.setTransform(58.6,14);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBGIAAiLIAdAAIAACLg");
	this.shape_10.setTransform(47.6,14);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhABGIAAiLIA3AAQAIAAAHABQAHACAHADIANAGIAKAIIAJAKIAHAMIAEANIABAOIAAAAQAAAHgBAIIgEAMIgHAMIgJALIgKAJIgNAFQgHADgHACQgHABgIAAgAghAqIAYAAQAJAAAHgDQAIgDAGgGQAFgFADgHQADgJAAgJIAAAAQAAgIgDgIQgDgIgFgFQgGgGgIgDQgHgDgJAAIgYAAg");
	this.shape_11.setTransform(36.7,14);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_12.setTransform(22.1,14);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAnBGIAAhaIgnA6IAAAAIgng6IAABaIgeAAIAAiLIAhAAIAkA7IAlg7IAhAAIAACLg");
	this.shape_13.setTransform(6.3,14);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2b, new cjs.Rectangle(-4.4,3,206.7,24), null);


(lib.txtline2a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBHIgOgEQgHgCgFgEIgLgJIgJgKQgEgHgCgGIgEgNIgCgQIAAAAQAAgGACgIIAEgNIAGgNIAJgKIALgJQAGgEAGgCIAOgFQAIgCAHABQAJgBAIACQAIABAGACQAJAEAPALIgUAXQgIgHgIgEQgJgDgLAAQgHAAgIADQgHAEgGAGQgFAGgDAIQgDAIAAAIIAAAAQAAAKADAIQADAIAFAGQAGAGAIADQAIADAIABQAIAAAIgCQAHgDAGgEIAAgUIgfAAIAAgZIA9AAIAAA7QgQAMgKAEIgQAFQgJACgJAAQgHgBgIgBg");
	this.shape.setTransform(204.7,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAkBGIhDhYIAABYIgeAAIAAiLIAcAAIBBBVIAAhVIAeAAIAACLg");
	this.shape_1.setTransform(189.2,6.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPBGIAAiLIAfAAIAACLg");
	this.shape_2.setTransform(178.1,6.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPBGIAAhvIgqAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_3.setTransform(168.4,6.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOBGIAAiLIAdAAIAACLg");
	this.shape_4.setTransform(158.6,6.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHBHIgNgEIgNgHIgKgIIgJgLQgEgGgCgHIgEgNQgCgHAAgIIAAAAQAAgGACgIIAEgNQACgGAEgHIAJgKIAKgJQAGgEAHgCIAOgFQAGgCAIABQAKgBAIACQAIABAHAEQAJADAOAMIgUAXQgJgIgIgEQgJgEgKAAQgIAAgHADQgHAEgGAGQgFAGgDAHQgDAJAAAIIAAAAQAAAJADAIQACAIAGAGQAFAGAIADQAHAEAIAAQAIAAAMgFQAIgDAJgIIAUATIgMALQgGAEgGADQgHAEgIACQgJACgKAAIgOgCg");
	this.shape_5.setTransform(148.1,6.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAfBGIgfgwIgfAwIgjAAIAxhGIgvhFIAkAAIAdAtIAdgtIAjAAIguBFIAwBGg");
	this.shape_6.setTransform(133.4,6.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_7.setTransform(119.8,6.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPAEQAKAEAHAGQAGAGADAIQADAJAAAJQAAAJgCAHQgCAHgEAEQgEAGgGADQgFAEgHADIAjAygAgdgBIAeAAQAGAAAEgBIAIgFIAFgGQABgEAAgEQAAgFgCgEQgCgDgCgDQgDgDgFgBIgLgBIgdAAg");
	this.shape_8.setTransform(100.3,6.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_9.setTransform(86.3,6.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNBGIg4iLIAiAAIAkBhIAkhhIAhAAIg5CLg");
	this.shape_10.setTransform(71.9,6.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBHIgOgEIgNgHIgLgIIgJgMIgGgMIgEgNQgCgHABgIIAAAAQgBgGACgIIAEgNIAHgNIAIgKIALgJQAGgEAIgCQAGgEAHgBQAIgCAHABQAIgBAIACIAOAFQAGACAHAEQAFAEAFAEIAJALIAHANIAEANQABAHAAAHIAAAAQAAAHgBAIIgEANIgHAMIgJALIgKAJQgHAEgHACQgGAEgHABQgIABgIABIgPgCgAgQgoQgIAEgFAGQgGAGgDAHQgDAJAAAIIAAAAQAAAJADAIQADAIAGAGQAFAGAIADQAIAEAIAAQAJAAAIgEQAIgDAGgGQAFgGADgHQADgIAAgKIAAAAQAAgIgDgIQgDgIgFgGQgHgGgHgEQgIgDgJAAQgJAAgHADg");
	this.shape_11.setTransform(56,6.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHBHIgNgEIgNgHIgKgIIgJgLQgEgGgCgHIgEgNQgCgHAAgIIAAAAQAAgGACgIIAEgNQACgGAEgHIAJgKIAKgJQAGgEAHgCIAOgFQAGgCAIABQAKgBAIACQAIABAHAEQAJADAOAMIgUAXQgJgIgIgEQgJgEgKAAQgIAAgHADQgHAEgGAGQgFAGgDAHQgDAJAAAIIAAAAQAAAJADAIQACAIAGAGQAFAGAIADQAHAEAIAAQAIAAAMgFQAIgDAJgIIAUATIgMALQgGAEgGADQgHAEgIACQgJACgKAAIgOgCg");
	this.shape_12.setTransform(40.3,6.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgLBHIgPgFIgPgGIgOgLIATgVQAKAIAJAEIALAEIALABQAJAAAFgDQAGgEAAgHIAAAAQAAgGgGgEQgFgDgQgFIgTgFQgKgEgFgEQgHgEgDgHQgCgIAAgJIAAgBQgBgJAEgIQADgIAHgGQAGgFAJgDQAJgDALAAIAOABIANADIANAGIALAIIgQAXQgKgGgIgEQgKgEgHAAQgJAAgEAEQgFADAAAFIAAABQAAAGAGAEQAGAEARAEQAMADAHADQAIAEAGAEQAFAFADAGQADAHAAAJIAAAAQAAALgDAIQgEAIgHAGQgHAFgJADQgKADgLAAQgHAAgIgBg");
	this.shape_13.setTransform(26.4,6.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgOBGIAAiLIAdAAIAACLg");
	this.shape_14.setTransform(16.9,6.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag/BGIAAiLIA2AAQAIAAAGABQAIACAHADIANAFIALAJIAJAKIAGAMIAEANIABAOIAAAAQAAAHgBAIIgEANIgGALIgJALIgLAIIgNAGQgHADgIACQgGABgIAAgAghAqIAYAAQAJAAAHgDQAIgDAFgGQAGgFADgHQADgIAAgKIAAAAQAAgIgDgIQgDgIgGgFQgFgGgIgDQgHgDgJAAIgYAAg");
	this.shape_15.setTransform(6.2,6.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline2a, new cjs.Rectangle(-4,-4.7,218.8,24), null);


(lib.txtline1d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfIAfAAIAAAfg");
	this.shape.setTransform(154,15.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_1.setTransform(144,10.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPADQAKAEAHAHQAGAGADAIQADAJAAAKQAAAIgCAHQgCAHgEAFQgEAFgGAEQgFADgHADIAjAygAgdgBIAeAAQAGAAAEgCIAIgDIAEgGQACgEAAgFQAAgFgCgEQgBgEgDgCQgDgDgFgBIgKgBIgeAAg");
	this.shape_2.setTransform(129.5,10.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_3.setTransform(114.5,10.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdBGIAAg4Ig5AAIAAA4IgeAAIAAiLIAeAAIAAA4IA5AAIAAg4IAeAAIAACLg");
	this.shape_4.setTransform(99.1,10.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAgBHIgghbIgfBbIgaAAIgwiMIAhAAIAdBeIAfhfIAaAAIAfBfIAdheIAgAAIgwCMg");
	this.shape_5.setTransform(79.5,10.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBGIAAg3Ig1hUIAkAAIAgA4IAig4IAjAAIg2BTIAAA4g");
	this.shape_6.setTransform(60.4,10.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAYBGIgcgtIgZAAIAAAtIgeAAIAAiLIA/AAQAIAAAPADQAKAEAHAHQAGAGADAIQADAJAAAKQAAAIgCAHQgCAHgEAFQgEAFgFAEQgGADgHADIAiAygAgdgBIAeAAQAGAAAFgCIAGgDIAGgGQABgEAAgFQAAgFgCgEQgBgEgEgCQgDgDgEgBIgLgBIgdAAg");
	this.shape_7.setTransform(45.7,10.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_8.setTransform(30.8,10.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMBHIg5iNIAiAAIAjBiIAlhiIAhAAIg4CNg");
	this.shape_9.setTransform(15.5,10.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_10.setTransform(0.8,10.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1d, new cjs.Rectangle(-8.2,-0.7,168.1,24), null);


(lib.txtline1c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfIAfAAIAAAfg");
	this.shape.setTransform(120,18.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBGIAAhvIgqAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_1.setTransform(110.2,13);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLBHIgPgFIgPgGIgOgLIATgVQAKAIAJAEIALAEIALABQAJAAAGgDQAFgEAAgHIAAAAQAAgGgFgEQgGgDgRgFIgSgFQgKgEgFgEQgHgEgDgHQgCgIAAgJIAAgBQAAgJADgIQADgIAHgGQAGgFAJgDQAKgDAKAAIAOABIANADIANAGIALAIIgQAXQgJgGgJgEQgKgEgHAAQgJAAgEAEQgFADAAAFIAAABQAAAGAGAEQAGAEARAEQAMADAHADQAIAEAGAEQAFAFADAGQADAHABAJIAAAAQAAALgEAIQgEAIgHAGQgHAFgJADQgKADgLAAQgHAAgIgBg");
	this.shape_2.setTransform(96.7,13);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPBHIgOgEIgNgHIgLgIIgIgMIgHgMIgEgNQgBgHAAgHIAAgBQAAgGABgIIAEgNIAHgNIAIgKIALgJQAHgEAHgCQAGgEAHgBQAIgCAHABQAIgBAIACIAOAFQAGACAHAEQAGAEAFAEIAJALIAGANIAEANQACAHgBAHIAAAAQABAHgCAIIgEANIgHAMIgIALIgLAJQgHAEgHACQgGAEgHABQgIABgIABIgPgCgAgQgoQgIAEgFAGQgGAGgDAHQgDAJAAAIIAAAAQAAAJADAIQADAIAGAGQAFAGAIADQAIAEAIAAQAKAAAHgEQAIgDAFgGQAGgGADgHQADgIAAgJIAAgBQAAgIgDgIQgDgIgGgGQgFgGgIgEQgIgDgJAAQgIAAgIADg");
	this.shape_3.setTransform(81.4,13);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAnBGIAAhaIgnA6IAAAAIgng6IAABaIgeAAIAAiLIAhAAIAkA7IAlg7IAhAAIAACLg");
	this.shape_4.setTransform(63.8,13);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_5.setTransform(41.7,13);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAdBGIAAg4Ig5AAIAAA4IgeAAIAAiLIAeAAIAAA3IA5AAIAAg3IAeAAIAACLg");
	this.shape_6.setTransform(26.6,13);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgPBGIAAhvIgqAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_7.setTransform(12,13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1c, new cjs.Rectangle(3.5,2,122.1,24), null);


(lib.txtline1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhABGIAAiLIA3AAQAIAAAGABQAIABAHAEIANAFIAKAJIAJAKIAHAMIAEANIACAOIAAAAQAAAIgCAGIgEAOIgHALIgJALIgKAIIgNAGQgHADgIABQgGACgIAAgAghAqIAYAAQAJAAAHgDQAIgDAGgGQAFgFADgHQADgIAAgJIAAgBQAAgIgDgIQgDgHgFgHQgGgFgIgDQgHgDgJAAIgYAAg");
	this.shape.setTransform(211.9,14.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_1.setTransform(197.2,14.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag/BGIAAiLIA2AAQAIAAAHABQAHABAHAEIANAFIALAJIAJAKIAGAMIAEANQACAHgBAHIAAAAQABAIgCAGIgEAOIgGALIgJALIgLAIIgNAGQgHADgHABQgHACgIAAgAghAqIAYAAQAJAAAHgDQAIgDAFgGQAGgFADgHQADgIAAgJIAAgBQAAgIgDgIQgDgHgGgHQgFgFgIgDQgHgDgJAAIgYAAg");
	this.shape_2.setTransform(182.7,14.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_3.setTransform(168,14.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_4.setTransform(154.5,14.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAkBGIhDhYIAABYIgeAAIAAiLIAcAAIBBBVIAAhVIAeAAIAACLg");
	this.shape_5.setTransform(139.5,14.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgKBHIgQgFIgPgHIgNgKIASgVQAKAIAJAEIALAEIALABQAJAAAFgEQAGgDAAgHIAAAAQAAgGgGgEQgFgDgQgFIgTgFQgJgEgGgEQgGgEgDgHQgDgIAAgJIAAgBQAAgJADgIQAEgIAGgGQAGgFAKgDQAIgDALAAIAOABIANADIANAGIAMAIIgQAXQgLgHgIgDQgJgEgIAAQgIAAgGAEQgEADAAAFIAAABQAAAGAGAEQAGADARAFQALADAIADQAJAEAFAEQAGAFADAGQACAHAAAJIAAABQABAKgEAIQgEAIgHAGQgGAGgKACQgJADgMAAQgHAAgHgBg");
	this.shape_6.setTransform(118.9,14.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSAgIAEg/IAhAAIAAABIgVA+g");
	this.shape_7.setTransform(109.8,10.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBGIAAhvIgrAAIAAgcIBzAAIAAAcIgrAAIAABvg");
	this.shape_8.setTransform(100.3,14.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgPBGIAAiLIAfAAIAACLg");
	this.shape_9.setTransform(90.3,14.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_10.setTransform(74.4,14.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAZBGIgdgtIgZAAIAAAtIgeAAIAAiLIA/AAQAIAAAPADQAKAFAHAGQAGAGADAIQADAIAAAKQAAAJgCAHQgCAHgEAEQgEAGgFADQgGAEgHADIAiAygAgdgBIAeAAQAGAAAFgCIAGgEIAGgGQABgEAAgEQAAgFgCgEQgBgEgEgCQgDgCgEgCIgLgBIgdAAg");
	this.shape_11.setTransform(60.6,14.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAbIhKAAIAAAdIBBAAIAAAaIhBAAIAAAeIBLAAIAAAbg");
	this.shape_12.setTransform(46.3,14.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAdBGIAAg4Ig5AAIAAA4IgeAAIAAiLIAeAAIAAA3IA5AAIAAg3IAeAAIAACLg");
	this.shape_13.setTransform(31.6,14.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAgBHIgghbIgfBbIgaAAIgwiMIAhAAIAdBeIAfhfIAaAAIAfBfIAdheIAgAAIgwCMg");
	this.shape_14.setTransform(12.7,14.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1b, new cjs.Rectangle(-0.5,3.3,222.1,24), null);


(lib.txtline1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape.setTransform(180.4,10.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPADQAKAEAHAHQAGAGADAIQADAJAAAKQAAAIgCAHQgCAHgEAFQgEAFgGAEQgFADgHADIAjAygAgdgBIAeAAQAGAAAEgCIAIgDIAFgGQABgEAAgFQAAgFgCgEQgCgEgCgCQgDgDgFgBIgLgBIgdAAg");
	this.shape_1.setTransform(166.9,10.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAqBHIgNggIg6AAIgNAgIgfAAIA8iNIAbAAIA8CNgAASAMIgSgtIgSAtIAkAAg");
	this.shape_2.setTransform(151.5,10.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHBHIgNgEIgNgHIgKgJIgJgKQgEgGgCgGIgEgOQgCgHAAgIIAAAAQAAgHACgGIAEgOQACgHAEgFIAJgLIAKgJQAGgEAHgDIAOgEQAGgCAIAAQAKAAAIACQAIACAHACQAJAEAOAMIgUAXQgJgIgIgEQgJgEgKAAQgIAAgHAEQgHADgGAGQgFAGgDAHQgDAJAAAIIAAAAQAAAJADAIQACAIAGAGQAFAGAIAEQAHADAIAAQAIAAAMgEQAIgEAJgJIAUAVIgMAKQgGAEgGAEQgHADgIABQgJACgKAAIgOgBg");
	this.shape_3.setTransform(136.5,10.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAZBGIgegtIgYAAIAAAtIgfAAIAAiLIA/AAQAJAAAPADQAKAEAHAHQAGAGADAIQADAJAAAKQAAAIgCAHQgCAHgEAFQgEAFgGAEQgFADgHADIAjAygAgdgBIAfAAQAFAAAEgCIAIgDIAEgGQACgEAAgFQAAgFgCgEQgBgEgDgCQgDgDgFgBIgKgBIgeAAg");
	this.shape_4.setTransform(115.5,10.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBDQgFgBgFgEQgFgDgEgDIgHgJIgEgLQgDgGgBgHIgBgOIAAhPIAfAAIAABOQAAAJACAGQACAGAEAFQAEAEAGACQAFADAGAAQAHAAAGgDQAFgBAFgFQADgEACgGQACgGAAgJIAAhPIAfAAIAABOIgBAPIgDANIgFALIgIAJIgJAGQgEAEgGABQgQAEgJAAQgRgBgIgDg");
	this.shape_5.setTransform(100.4,10.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBHIgOgEIgNgHIgLgJIgJgKIgGgMIgEgOQgBgHAAgIIAAAAQAAgHABgGIAEgOIAHgMIAIgLIALgJQAHgEAHgDQAGgCAHgCQAIgCAHAAIAQACIAOAEQAGADAHAEQAGADAFAGIAJALIAGALIAEAOQACAHgBAHIAAAAQABAHgCAHIgEAOIgHANIgIAKIgLAJQgHAEgHADQgGADgHABQgIABgIAAIgPgBgAgQgnQgIADgFAGQgGAGgDAHQgDAJAAAIIAAAAQAAAJADAIQADAIAGAGQAFAGAIAEQAIADAIAAQAKAAAHgDQAIgDAFgHQAGgGADgIQADgHAAgKIAAAAQAAgIgDgIQgDgIgGgGQgFgGgIgDQgIgEgJAAQgIAAgIAEg");
	this.shape_6.setTransform(84.6,10.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgPBGIAAg3Ig1hUIAkAAIAgA4IAig4IAjAAIg2BTIAAA4g");
	this.shape_7.setTransform(69.1,10.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0BGIAAiLIBoAAIAAAcIhKAAIAAAcIBBAAIAAAaIhBAAIAAAdIBLAAIAAAcg");
	this.shape_8.setTransform(50,10.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAaBGIgqg7IgQAQIAAArIgfAAIAAiLIAfAAIAAA9IA4g9IAlAAIg5A7IA7BQg");
	this.shape_9.setTransform(36.6,10.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAqBHIgNggIg6AAIgNAgIgfAAIA8iNIAbAAIA8CNgAASAMIgSgtIgSAtIAkAAg");
	this.shape_10.setTransform(20.9,10.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBGIAAhuIgqAAIAAgdIBzAAIAAAdIgrAAIAABug");
	this.shape_11.setTransform(7.5,10.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtline1a, new cjs.Rectangle(-1,-0.7,189.8,24), null);


(lib.redbg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E84639").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.redbg, new cjs.Rectangle(0,0,300,250), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAfIAAgZIgYglIAQAAIAOAaIAPgaIAQAAIgYAlIAAAZg");
	this.shape.setTransform(124.6,6.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AALAfIgMgUIgLAAIAAAUIgOAAIAAg+IAcAAIAKACQAFACADADQADADABADIABAJIgBAGIgCAFIgFAEIgFADIAPAWgAgMAAIANAAIAEAAIAEgDIACgCIAAgEIAAgEIgDgCIgDgCIgFgBIgMAAg");
	this.shape_1.setTransform(118.4,6.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATAgIgGgOIgaAAIgFAOIgOAAIAag/IAMAAIAbA/gAAIAFIgIgTIgHATIAPAAg");
	this.shape_2.setTransform(111.4,6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_3.setTransform(104.9,6.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_4.setTransform(100.5,6.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAg+IAOAAIAAAyIAfAAIAAAMg");
	this.shape_5.setTransform(96.5,6.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_6.setTransform(92,6.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIAQgbIAQAAIAAA+g");
	this.shape_7.setTransform(86.6,6.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAcAAIAAALIgcAAIAAANIAhAAIAAAMg");
	this.shape_8.setTransform(77.1,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AANAfIAAgZIgZAAIAAAZIgOAAIAAg+IAOAAIAAAaIAZAAIAAgaIAOAAIAAA+g");
	this.shape_9.setTransform(70.6,6.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAfIAAgwIgTAAIAAgOIAzAAIAAAOIgTAAIAAAwg");
	this.shape_10.setTransform(64.3,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAuAAIAAANIggAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_11.setTransform(45.7,6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAfIgdgmIAAAmIgOAAIAAg+IANAAIAdAnIAAgnIANAAIAAA+g");
	this.shape_12.setTransform(39,6.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_13.setTransform(33.9,6.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgCAgIgHgCIgGgDIgEgEIgEgEIgDgGIgBgGIgBgHIABgFIABgHIADgFIAEgFIAEgEIAHgDIAGgCIAFgBIAIABIAHACIAKAHIgJAKQgDgDgEgCQgEgCgFAAQgDAAgDACQgDABgCADIgFAGIgBAHQAAAEABAEIAFAGIAFAEQADACADAAQAEAAAFgCIAIgGIAJAJIgFAFIgGADIgHADIgIAAIgFAAg");
	this.shape_14.setTransform(29.2,6.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGAfIAAg+IANAAIAAA+g");
	this.shape_15.setTransform(24.3,6.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgcAfIAAg+IAYAAIAHABIAGACIAGADIAFADIADAFIAEAFIACAHIAAAFIAAAGIgCAGIgEAGIgDAEIgFAEIgGADIgGACIgHAAgAgOATIAKAAQAEAAADgBQAEgBADgDIADgGQACgDgBgFQABgDgCgDQgBgEgCgDIgHgDQgDgCgEAAIgKAAg");
	this.shape_16.setTransform(19.5,6.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAfIAAg+IAvAAIAAANIghAAIAAANIAdAAIAAALIgdAAIAAANIAhAAIAAAMg");
	this.shape_17.setTransform(13,6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASAfIAAgnIgSAaIAAAAIgRgaIAAAnIgNAAIAAg+IAOAAIAQAbIARgbIAPAAIAAA+g");
	this.shape_18.setTransform(5.9,6.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAgQgNgNAAgTQAAgSANgNQANgNASAAQATAAANANQANANAAASQAAATgNANQgNANgTAAQgSAAgNgNgAgaAKIATAAIAAATIAQAAIAAgTIATAAIAAgSIgTAAIAAgTIgQAAIAAATIgTAAg");
	this.shape_19.setTransform(55.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,130,13), null);


(lib.Humanitarian2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Humanitarian2();
	this.instance.parent = this;
	this.instance.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Humanitarian2_1, new cjs.Rectangle(-1,0,600,400), null);


(lib.Humanitarian1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Humanitarian1();
	this.instance.parent = this;
	this.instance.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Humanitarian1_1, new cjs.Rectangle(-1,0,600,400), null);


(lib.crosscover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgAgMAOIAaAAIAAgbIgaAAg");
	this.shape.setTransform(167.4,167.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E74637").s().p("A9rdrMAAAg7WMA7WAAAMAAAA7WgAjFDGIGLAAIAAmMImLAAg");
	this.shape_1.setTransform(169.7,169.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E74637").s().p("A+CeDMAAAg8FMA8FAAAMAAAA8FgAl0F1ILpAAIAArpIrpAAg");
	this.shape_2.setTransform(171.8,171.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E74637").s().p("A+ZeZMAAAg8yMA8zAAAMAAAA8zgAoaIaQQqABAKgBQABgKgBwqIw0AAg");
	this.shape_3.setTransform(173.9,173.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E74637").s().p("A+uevMAAAg9dMA9eAAAMAAAA9egAq2K2QVjACAJgCQACgJgC1jI1sAAg");
	this.shape_4.setTransform(175.8,175.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E74637").s().p("A/DfDMAAAg+GMA+GAAAMAAAA+GgAtINJQaIACAKgBQABgKgB6II6SAAg");
	this.shape_5.setTransform(177.6,177.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E74637").s().p("A/VfWMAAAg+rMA+rAAAMAAAA+rgAvRPSQebADAIgDQADgIgD+cI+jAAg");
	this.shape_6.setTransform(179.2,179.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E74637").s().p("A/nfnMAAAg/OMA/PAAAMAAAA/PgAxRRSUAibAADAAIgADUAADgAIgADgibMgijAAAg");
	this.shape_7.setTransform(180.8,180.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E74637").s().p("A/3f3MAAAg/uMA/vAAAMAAAA/vgAzHTIUAmIAADAAHgADUAADgAHgADgmIMgmPAAAg");
	this.shape_8.setTransform(182.2,182.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E74637").s().p("EggGAgGMAAAhAMMBANAAAMAAABANgA00U1UApiAADAAHgADUAADgAHgADgpiMgppAAAg");
	this.shape_9.setTransform(183.6,183.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E74637").s().p("EggTAgUMAAAhAnMBAnAAAMAAABAngA2XWYUAspAAEAAHgADUAADgAHgADgsqMgswAAAg");
	this.shape_10.setTransform(184.8,184.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E74637").s().p("EgggAggMAAAhBAMBBBAAAMAAABBBgA3xXyUAvdAAEAAGgAEUAAEgAGgAEgvdMgvjAAAg");
	this.shape_11.setTransform(185.9,185.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E74637").s().p("EggrAgrMAAAhBWMBBXAAAMAAABBXgA5BZDUAx/AADAAFgADUAADgAFgADgyAMgyEAAAg");
	this.shape_12.setTransform(186.9,186.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E74637").s().p("Egg0Ag1MAAAhBpMBBpAAAMAAABBpgA6JaJUA0NAAEAAGgADUAADgAGgADg0NMg0TAAAg");
	this.shape_13.setTransform(187.7,187.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E74637").s().p("Egg9Ag9MAAAhB6MBB7AAAMAAABB7gA7GbHUA2IAAEAAFgAEUAAEgAFgAEg2IMg2NAAAg");
	this.shape_14.setTransform(188.5,188.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E74637").s().p("EghEAhFMAAAhCJMBCJAAAMAAABCJgA76b7UA3xAAEAAEgAEUAAEgAEgAEg3xMg31AAAg");
	this.shape_15.setTransform(189.1,189.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E74637").s().p("EghKAhKMAAAhCUMBCVAAAMAAABCVgA8lclUA5GAAFAAFgAEUAAEgAFgAEg5GMg5LAAAg");
	this.shape_16.setTransform(189.6,189.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E74637").s().p("EghOAhPMAAAhCdMBCdAAAMAAABCdgA9GdGUA6JAAFAAEgAEUAAEgAEgAEg6JMg6NAAAg");
	this.shape_17.setTransform(190,190);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E74637").s().p("EghRAhSMAAAhCjMBCjAAAMAAABCjgA9edeUA64AAEAAEgAEUAAEgAEgAEg64Mg68AAAg");
	this.shape_18.setTransform(190.3,190.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E74637").s().p("EghUAhUMAAAhCoMBCoAAAMAAABCogA9sdsUA7VAAFAADgAFUAAFgADgAFg7VMg7YAAAg");
	this.shape_19.setTransform(190.5,190.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E74637").s().p("A9RdSMAAAg6jMA6jAAAMAAAA6jgA6JaKUA0QAAEAADgAEUAAEgADgAEg0QMg0TAAAg");
	this.shape_20.setTransform(0,0,1.138,1.138,0,0,0,-167.4,-167.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},4).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-20,374.9,374.9);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// LEARN MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACLAeIgHgCIgFgCIgFgEIgDgFIgDgFIgCgGIAAgGIAAAAIAAgFIACgGIADgFIAEgFIAFgDIAEgDIAHgCIAGgBIAHABIAGACIAFADIAEADIAFAFIACAFIABAGIABAFIgBAGIgBAGIgDAFIgEAFIgEADIgFADIgHACIgGABIgGgBgACJgTIgGAFQgDADgBAEIgCAHQAAAEACAEIAEAHQACADAEABQAEACAEAAQAEAAAFgCQADgBACgDQADgDACgEIACgIIAAAAIgCgHQgCgEgDgDQgCgDgEgBQgEgCgEAAQgFAAgDABgAD9AeIAAg7IAsAAIAAAKIgiAAIAAAPIAeAAIAAAIIgeAAIAAAQIAiAAIAAAKgADlAeIgQgVIgMAAIAAAVIgLAAIAAg7IAbAAIAKACQAEABADADIAEAGQABADAAAEQAAAEgBADIgDAEIgFAEIgGACIAQAXgADJAAIAPAAIAFAAIAEgCIADgDIAAgEIAAgFIgDgDIgEgCIgFAAIgPAAgABZAeIAAgqIgSAbIgBAAIgSgbIAAAqIgLAAIAAg7IAMAAIASAcIASgcIALAAIAAA7gAgKAeIgggqIAAAqIgLAAIAAg7IAKAAIAfAoIAAgoIALAAIAAA7gAhNAeIgPgVIgNAAIAAAVIgKAAIAAg7IAaAAIAKACQAEABADADIAEAGQABADAAAEQAAAEgBADIgCAEIgFAEIgGACIAQAXgAhpAAIAPAAIAFAAIAEgCIADgDIABgEIgBgFIgDgDIgEgCIgFAAIgPAAgAiKAeIgGgPIgcAAIgGAPIgLAAIAag7IAKAAIAaA7gAiUAGIgKgXIgKAXIAUAAgAjyAeIAAg7IAsAAIAAAKIghAAIAAAPIAdAAIAAAIIgdAAIAAAQIAhAAIAAAKgAkoAeIAAg7IALAAIAAAxIAfAAIAAAKg");
	this.shape.setTransform(-0.1,-0.6,1.321,1.32);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BUTTON
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2383A8").s().p("Al3BjQgpAAgdgdQgdgdAAgpQAAgoAdgdQAdgdApAAILvAAQApAAAdAdQAdAdAAAoQAAApgdAdQgdAdgpAAg");
	this.shape_1.setTransform(-0.2,0,1.321,1.32);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-62.9,-13.1,125.6,26.2), null);


(lib.bigBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,150,1,1.2);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mainimg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_334 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(334).call(this.frame_334).wait(1));

	// Technology-2
	this.instance = new lib.Humanitarian2_1();
	this.instance.parent = this;
	this.instance.setTransform(161.8,130,0.651,0.651,0,0,0,300,199.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:185.8},334,cjs.Ease.quadOut).wait(1));

	// Technology-1
	this.instance_1 = new lib.Humanitarian1_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(174.6,130,0.651,0.651,0,0,0,300,199.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:184.6},334,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,0,403.2,260.3);


// stage content:
(lib.MedPlus_Banner_everywhere_300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// Enable mouse interaction with the stage 
		stage.enableMouseOver();
		
		// Define variables used in the 
		var root = this;
		var bigBtn = root.bigBtn;
		var cta = root.cta;
		var legalBtn = root.legalBtn;
		var legalPop = root.legalPop;
		
		// Add event listeners
		bigBtn.addEventListener("click", clickTag);
		bigBtn.addEventListener("mouseover", rollOver);
		bigBtn.addEventListener("mouseout", rollOut);
		/*
		legalBtn.addEventListener("click", legalUp);
		legalPop.addEventListener("click", legalDown);
		*/
		// Define functions to use throughout 
		function rollOver(){
			TweenMax.to(cta, .25, {scaleX:1.1, scaleY:1.1}); 
		};
		
		function rollOut(){
			TweenMax.to(cta, .25, {scaleX:1, scaleY:1});
		};
		
		function clickTag() {
			window.open(window.clickTag);
		}
		/*
		function legalUp(){
			TweenMax.to(legalPop, .5, {y:0, ease: Power1.easeOut}); 
		};
		
		function legalDown(){
			TweenMax.to(legalPop, .5, {y:250, ease: Power1.easeOut}); 
		};
		*/
	}
	this.frame_249 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(249).call(this.frame_249).wait(1));

	// bigBtn
	this.bigBtn = new lib.bigBtn();
	this.bigBtn.parent = this;
	this.bigBtn.setTransform(150,0,1,2,0,0,0,150,0);
	new cjs.ButtonHelper(this.bigBtn, 0, 1, 2, false, new lib.bigBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bigBtn).wait(250));

	// cta
	this.cta = new lib.cta();
	this.cta.parent = this;
	this.cta.setTransform(-85.7,490.4,1.321,1.321);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(239).to({scaleX:0.05,scaleY:0.05,x:102.9,y:495.2},0).to({regX:0.1,scaleX:0.99,scaleY:0.99,x:103.4,y:495.4},10,cjs.Ease.backOut).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(123.2,571.2,1.316,1.316,0,0,0,65,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(250));

	// txt-line-2a
	this.instance_1 = new lib.txtline2a();
	this.instance_1.parent = this;
	this.instance_1.setTransform(111.5,415.8,1,1,0,0,0,68.5,8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(199).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2b
	this.instance_2 = new lib.txtline2b();
	this.instance_2.parent = this;
	this.instance_2.setTransform(107.9,429,1,1,0,0,0,64.5,8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(199).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-2c
	this.instance_3 = new lib.txtline2c();
	this.instance_3.parent = this;
	this.instance_3.setTransform(100.8,453,1,1,0,0,0,57.4,8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(199).to({_off:false},0).to({alpha:1},8).wait(43));

	// txt-line-1a
	this.instance_4 = new lib.txtline1a();
	this.instance_4.parent = this;
	this.instance_4.setTransform(100.3,411.8,1,1,0,0,0,60,8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(38).to({_off:false},0).to({alpha:1},8).wait(123).to({alpha:0},8).wait(73));

	// txt-line-1b
	this.instance_5 = new lib.txtline1b();
	this.instance_5.parent = this;
	this.instance_5.setTransform(90.8,428.9,1,1,0,0,0,51,8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(38).to({_off:false},0).to({alpha:1},8).wait(123).to({alpha:0},8).wait(73));

	// txt-line-1c
	this.instance_6 = new lib.txtline1c();
	this.instance_6.parent = this;
	this.instance_6.setTransform(90.7,450.9,1,1,0,0,0,54.9,8);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(38).to({_off:false},0).to({alpha:1},8).wait(123).to({alpha:0},8).wait(73));

	// txt-line-1d
	this.instance_7 = new lib.txtline1d();
	this.instance_7.parent = this;
	this.instance_7.setTransform(105.6,474.7,1,1,0,0,0,58.1,8);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(94).to({_off:false},0).to({alpha:1},8).wait(67).to({alpha:0},8).wait(73));

	// cross-cover
	this.instance_8 = new lib.crosscover();
	this.instance_8.parent = this;
	this.instance_8.setTransform(126.4,188.9,1.157,1.157,0,0,0,167.2,167.4);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:171.9,alpha:1},5,cjs.Ease.sineOut).wait(245));

	// cross-mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_5 = new cjs.Graphics().p("As3dgIAA4MIuQAAIAA5zIOQAAIAApAIZvAAIAAJAIOQAAIAAZzIuQAAIAAYMg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(5).to({graphics:mask_graphics_5,x:126.4,y:188.9}).wait(245));

	// main-img
	this.instance_9 = new lib.mainimg();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-110.1,0.2,1.511,1.511,0,0,0,-0.1,0.1);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(5).to({_off:false},0).wait(245));

	// red-bg
	this.instance_10 = new lib.redbg();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(250));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.9,272,512.5,628);
// library properties:
lib.properties = {
	id: '921C301E2A774CFD85816EFEBF3EA78D',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/MedPlus_Banner_everywhere_300x600_atlas_.png?1506103842521", id:"MedPlus_Banner_everywhere_300x600_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['921C301E2A774CFD85816EFEBF3EA78D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;